// 09-anotacoes.js — Sistema de anotações (texto rico, tabelas)
// Parte do script do app (v2.0.1). Arquivo comum, carregado em ordem pelo index.html; compartilha funções e variáveis globais com os demais.
// --- SISTEMA DE ANOTAÇÕES (múltiplas notas, texto rico, tabelas) ---

function stripHtmlAnotacao(html) {
    const tmp = document.createElement('div');
    tmp.innerHTML = html || '';
    // textContent concatena blocos (<p>, <div>, <li>...) sem nenhum espaço
    // entre eles — "RIOCLARENSE Ped. 1698" + "Pedido: SERINGA..." virava
    // "RIOCLARENSE Ped. 1698Pedido: SERINGA..." colado. Insere um espaço no
    // fim de cada bloco antes de extrair o texto, sem criar quebra de linha.
    tmp.querySelectorAll('p, div, li, h1, h2, h3, h4, br').forEach(el => {
        el.insertAdjacentText('afterend', ' ');
    });
    return (tmp.textContent || tmp.innerText || '').replace(/\s+/g, ' ').trim();
}

function renderListaAnotacoes() {
    const container = document.getElementById('lista-anotacoes-container');
    if (!container) return;

    const termo = filtroAnotacoesTexto.trim().toUpperCase();
    const lista = listaAnotacoes.filter(a => {
        if (!termo) return true;
        const titulo = (a.titulo || '').toUpperCase();
        const texto = stripHtmlAnotacao(a.conteudo).toUpperCase();
        return titulo.includes(termo) || texto.includes(termo);
    });

    if (lista.length === 0) {
        container.innerHTML = `<div class="empty-state">${listaAnotacoes.length === 0 ? 'Nenhuma anotação ainda. Toque em "Nova Anotação" para começar.' : 'Nenhuma anotação encontrada.'}</div>`;
        return;
    }

    container.innerHTML = lista.map(a => {
        const snippet = stripHtmlAnotacao(a.conteudo).slice(0, 90) || 'Sem conteúdo ainda...';
        const data = a.atualizadoEm ? new Date(a.atualizadoEm).toLocaleString('pt-BR') : '';
        const concluida = a.status === 'concluido';
        const sinalizada = !!a.sinalizada;
        const selecionada = selecaoAnotacoesAtiva && anotacoesSelecionadas.has(a.id);
        return `<div class="nota-item anotacao-item ${concluida ? 'anotacao-concluida' : ''} ${selecionada ? 'nota-selected' : ''}" onclick="${selecaoAnotacoesAtiva ? `toggleSelecaoAnotacao('${a.id}')` : (a.pedido ? `abrirCentralPedido('${a.pedido}')` : `abrirAnotacao('${a.id}')`)}">            <div class="nota-info">${a.titulo || 'Sem título'}${concluida ? ' <span class="badge-concluida">Concluída</span>' : ''}</div>
            <div class="nota-detalhes">${snippet}${snippet.length >= 90 ? '…' : ''}</div>
            <div class="nota-data">Atualizado em: ${data}</div>
            ${!selecaoAnotacoesAtiva ? `<div class="anotacao-card-actions">
                <button type="button" class="anotacao-icon-btn ${sinalizada ? 'is-flagged' : ''}" title="Sinalizar" onclick="event.stopPropagation(); toggleFlagAnotacao('${a.id}')"><i class="fa-solid fa-flag"></i></button>
                <button type="button" class="anotacao-icon-btn ${concluida ? 'is-done' : ''}" title="${concluida ? 'Reabrir' : 'Concluir'}" onclick="event.stopPropagation(); toggleConcluidaAnotacao('${a.id}')"><i class="fa-solid fa-check"></i></button>
                <button type="button" class="anotacao-icon-btn is-delete" title="Excluir" onclick="event.stopPropagation(); excluirAnotacaoRapida('${a.id}')"><i class="fa-solid fa-trash"></i></button>
            </div>` : ''}
        </div>`;
    }).join('');
}

function toggleFlagAnotacao(id) {
    const nota = listaAnotacoes.find(a => a.id === id);
    if (!nota) return;
    const novoValor = !nota.sinalizada;
    anotacoesTextoCollection.doc(id).update({ sinalizada: novoValor })
        .catch(e => { console.error('Erro ao sinalizar anotação:', e); toast('✕ Erro ao sinalizar.'); });
}

function toggleConcluidaAnotacao(id) {
    const nota = listaAnotacoes.find(a => a.id === id);
    if (!nota) return;
    const novoStatus = nota.status === 'concluido' ? null : 'concluido';
    anotacoesTextoCollection.doc(id).update({ status: novoStatus })
        .then(() => toast(novoStatus ? '✓ Marcada como concluída.' : 'Reaberta.'))
        .catch(e => { console.error('Erro ao concluir anotação:', e); toast('✕ Erro ao atualizar.'); });
}

function excluirAnotacaoRapida(id) {
    const nota = listaAnotacoes.find(a => a.id === id);
    showConfirmModal({
        title: 'Excluir Anotação',
        message: `Deseja excluir "${nota ? (nota.titulo || 'Sem título') : 'esta anotação'}" permanentemente?`,
        confirmText: 'Excluir',
        confirmClass: 'danger',
        onConfirm: async () => {
            try {
                await anotacoesTextoCollection.doc(id).delete();
                toast('🗑️ Anotação excluída.');
            } catch (e) {
                console.error('Erro ao excluir anotação:', e);
                toast('✕ Erro ao excluir.');
            }
        }
    });
}

function filtrarAnotacoes(texto) {
    filtroAnotacoesTexto = texto;
    renderListaAnotacoes();
}

// --- Seleção múltipla para exportar relatório consolidado pro WhatsApp
// (vários pedidos diferentes numa mensagem só, sem redigitar). ---
function toggleModoSelecaoAnotacoes() {
    selecaoAnotacoesAtiva = !selecaoAnotacoesAtiva;
    anotacoesSelecionadas.clear();
    const btn = document.getElementById('btn-selecionar-anotacoes');
    const barra = document.getElementById('anotacoes-bulk-bar');
    if (btn) btn.classList.toggle('active', selecaoAnotacoesAtiva);
    if (barra) barra.style.display = selecaoAnotacoesAtiva ? 'flex' : 'none';
    atualizarContadorSelecaoAnotacoes();
    renderListaAnotacoes();
}
function toggleSelecaoAnotacao(id) {
    if (anotacoesSelecionadas.has(id)) anotacoesSelecionadas.delete(id);
    else anotacoesSelecionadas.add(id);
    atualizarContadorSelecaoAnotacoes();
    renderListaAnotacoes();
}
function atualizarContadorSelecaoAnotacoes() {
    const el = document.getElementById('anotacoes-selecao-contador');
    if (el) el.textContent = anotacoesSelecionadas.size > 0 ? `${anotacoesSelecionadas.size} selecionada(s)` : 'Toque nas anotações para selecionar';
    if (typeof dockSelecaoAtualizar === 'function') dockSelecaoAtualizar('anotacoes', selecaoAnotacoesAtiva, anotacoesSelecionadas.size, false);   // dock de seleção (js/38)
}
async function exportarAnotacoesWhatsapp() {
    if (anotacoesSelecionadas.size === 0) return toast('Selecione ao menos uma anotação.');
    const selecionadas = listaAnotacoes.filter(a => anotacoesSelecionadas.has(a.id));
    // Mantém a ordem em que aparecem na lista (mais recentes primeiro), não a
    // ordem de clique.
    const blocos = selecionadas.map(a => {
        const texto = stripHtmlAnotacao(a.conteudo).trim();
        return `*${a.titulo || 'Sem título'}*${texto ? '\n' + texto : ''}`;
    });
    const relatorio = blocos.join('\n\n———\n\n');
    if (navigator.share) {
        try {
            await navigator.share({ title: 'Relatório de Anotações', text: relatorio });
        } catch (e) {
            // usuário cancelou o share sheet — não é erro
        }
    } else {
        await navigator.clipboard.writeText(relatorio);
        toast('✓ Relatório copiado! Cole no WhatsApp.');
    }
}

function abrirNovaAnotacao() {
    voltarAnotacaoEditorParaCentral = null; // reseta — só a Central religa essa flag explicitamente
    anotacaoAtualId = null;
    document.getElementById('anotacao-titulo').value = '';
    document.getElementById('anotacao-corpo').innerHTML = '';
    aplicarEstadoEspacamentoEditor('', false);
    switchToScreen('screen-anotacoes-editor', 'Nova Anotação');
    setTimeout(() => { document.getElementById('anotacao-titulo').focus(); atualizarEstadoToolbarAnotacao(); }, 300);
}

function abrirAnotacao(id, viaCentral) {
    const nota = listaAnotacoes.find(a => a.id === id);
    if (!nota) return;
    if (!viaCentral) voltarAnotacaoEditorParaCentral = null; // reseta se aberta direto da lista, não da Central
    anotacaoAtualId = id;
    document.getElementById('anotacao-titulo').value = nota.titulo || '';
    document.getElementById('anotacao-corpo').innerHTML = nota.conteudo || '';
    aplicarEstadoEspacamentoEditor(nota.espacamentoLinha || '', !!nota.paragrafoCompacto);
    switchToScreen('screen-anotacoes-editor', nota.titulo || 'Anotação');
    setTimeout(atualizarEstadoToolbarAnotacao, 300);
}

// ============================================================
// CENTRAL DO PEDIDO — tela própria (não mais um painel dentro do editor de
// anotação). cotacoes/{pedido} continua sendo a única fonte da cotação;
// anotacoesTexto continua sendo a única fonte de ocorrências/divergências/
// status/histórico. Esta tela só JUNTA as duas na apresentação — nenhum
// dado é copiado de um lado pro outro.
//
// STATUS de uma divergência: 'pendente' (padrão, inclusive pra ocorrências
// antigas sem esse campo — nunca migramos histórico antigo só pra
// adicionar o campo), 'resolvida' (problema corrigido de fato) ou
// 'encerrada' (caso finalizado sem necessariamente ter sido corrigido).
// HISTÓRICO é append-only: uma mudança de status NUNCA apaga ou reescreve
// uma entrada anterior, só acrescenta uma nova. O texto que foi gerado e
// salvo no momento da identificação nunca muda retroativamente.
// ============================================================
let centralPedidoAtual = null;
let centralFornecedoresAbertos = new Set();
let centralStatusFormAberto = new Set();
let voltarAnotacaoEditorParaCentral = null; // guarda o pedido, se o editor de texto foi aberto a partir da Central

const ROTULOS_HISTORICO = { identificacao: 'Identificado', resolucao: 'Resolvido', encerramento: 'Encerrado', reabertura: 'Reaberto', relato: 'Relatado', geracao: 'Gerado' };

// Fase 37: a cotação individual tem abas (Produtos · Anotações · Relatório · Dados), no mesmo padrão das abas de Relatórios.
function alternarAbaCentral(aba) {
    document.querySelectorAll('#screen-central-pedido .central-aba-pane').forEach(p => p.classList.toggle('ativa', p.dataset.aba === aba));
    document.querySelectorAll('#screen-central-pedido .central-abas .xml-filtro-btn').forEach(btn => btn.classList.toggle('active', btn.dataset.aba === aba));
}
function abrirCentralPedido(pedido) {
    if (!pedido) return;
    centralPedidoAtual = pedido;
    centralFornecedoresAbertos = new Set();
    centralStatusFormAberto = new Set();
    alternarAbaCentral('produtos'); // Fase 37: sempre abre na aba Produtos
    switchToScreen('screen-central-pedido', pedido);
    renderCentralPedidoCompleto(pedido);
}

// Linhas de texto (uma por material) de UMA divergência — reaproveita
// linhaMaterial()/paragrafoAvaria(), já usados na geração de texto da
// Auditoria (mesma lógica, não duplicada).
// Texto natural de uma ocorrência que NÃO é por material (multiMaterial:
// false) — hoje "fornecedor não entregou" e "frete em desacordo". Extraído
// como função própria pra não duplicar a mesma string em dois lugares
// (Central do Pedido via linhasDeMateriais, e a saída da Auditoria via
// gerarCorpoAuditoria) — um ajusta, o outro acompanha automaticamente.
function textoOcorrenciaUnica(tipo, c) {
    if (tipo === 'fornecedor_nao_entregou' || tipo === 'frete_indevido') return aplicarModeloAuditoria(modeloDoTipo(tipo), c || {}, {});
    return '';
}

// 2.10.5: auditorias ANTIGAS guardavam o produto em d.campos (um só) em vez de d.materiais[]. Sem isso, o relatório não mostrava o produto
// e três divergências diferentes pareciam a mesma. Esta função devolve sempre a lista de materiais, qualquer que seja o formato gravado.
function materiaisDaDivergencia(d) {
    if (!d) return [];
    if (Array.isArray(d.materiais) && d.materiais.length) return d.materiais;
    const def = TIPOS_DIVERGENCIA_AUDITORIA[d.tipo];
    const c = d.campos || {};
    const temProduto = c.produto || c.produtoPedido || c.produtoFaturado;
    if ((!def || def.multiMaterial) && temProduto) return [c];
    return [];
}
function linhasDeMateriais(d) {
    const def = TIPOS_DIVERGENCIA_AUDITORIA[d.tipo];
    if (!def) { // tipo que não existe mais: mostra o que foi gravado, sem inventar
        return materiaisDaDivergencia(d).map(m => [m.produto, m.quantidadePedida && 'pedida ' + m.quantidadePedida, m.quantidadeFaturada && 'faturada ' + m.quantidadeFaturada, m.quantidadeFisica && 'física ' + m.quantidadeFisica].filter(Boolean).join(' · ')).filter(Boolean);
    }
    if (def.multiMaterial) return materiaisDaDivergencia(d).map(m => (d.tipo === 'desacordo_especificacao' && !m.especificacaoEsperada && !m.especificacaoRecebida) ? `${upAud(m.produto)}: desacordo de especificação.` : d.tipo === 'avariado' ? `${upAud(m.produto)} — material avariado` : linhaMaterial(d.tipo, m)).filter(Boolean);
    const texto = textoOcorrenciaUnica(d.tipo, d.campos || {});
    return texto ? [texto] : [];
}

// Bloco de UMA divergência: linhas de material + status + histórico +
// controle pra mudar o status. ocIdx/divIdx são os índices reais dentro de
// nota.ocorrencias[ocIdx].divergencias[divIdx] — é como alterarStatusDivergenciaCentral
// sabe exatamente o que atualizar no Firestore.
function renderBlocoDivergencia(d, oc, ocIdx, divIdx) {
    const status = d.status || 'pendente'; // ocorrências antigas sem status viram "pendente" só na exibição
    const linhas = linhasDeMateriais(d);
    if (linhas.length === 0) return '';
    // 2.17.2: cartão único e fechado em si mesmo — o que é (tipo), de quem/qual NF/pedido, o texto, e a linha do tempo (o que foi registrado
    // e quando), tudo dentro da mesma moldura. "Pendente" da auditoria = pendência RELATADA (já com o responsável): cinza, não vermelho.
    const def = TIPOS_DIVERGENCIA_AUDITORIA[d.tipo];
    // 2.19.1: auditoria nova nasce "gerada" (relatado:false); só é "Pendência relatada" depois de você marcar. Auditoria antiga (sem o campo) segue relatada.
    const naoRelatada = status === 'pendente' && d.relatado === false;
    const rotuloStatus = naoRelatada ? 'Gerada, ainda não relatada' : status === 'pendente' ? 'Pendência relatada' : status === 'resolvida' ? 'Resolvida' : 'Encerrada';
    const linhasHTML = linhas.map(l => `<div class="cdv-linha">${escRel(l)}</div>`).join('');
    const chips = [oc.fornecedor ? upAud(oc.fornecedor) : '', oc.notaFiscal ? `NF ${oc.notaFiscal}` : '', centralPedidoAtual ? `Pedido ${centralPedidoAtual}` : ''].filter(Boolean)
        .map(x => `<span class="cdv-chip">${escRel(x)}</span>`).join('');

    const ROT = { identificacao: 'Relatada na auditoria', resolucao: 'Resolvida', encerramento: 'Encerrada', reabertura: 'Reaberta', relato: 'Relatada', geracao: 'Gerada' };
    const historico = d.historico || [];
    const historicoHTML = historico.length ? `<div class="cdv-hist">
        ${historico.map(h => `<div class="cdv-hist-item"><span class="cdv-ponto ${h.tipo === 'resolucao' ? 'ok' : h.tipo === 'encerramento' ? 'fim' : ''}"></span><span class="cdv-hist-data">${escRel(formatarDataBRSimples(h.data))}</span><span>${escRel(ROT[h.tipo] || ROTULOS_HISTORICO[h.tipo] || h.tipo)}${h.observacao ? ' — ' + escRel(h.observacao) : ''}</span></div>`).join('')}
    </div>` : '';

    const key = `${ocIdx}-${divIdx}`;
    const formAberto = centralStatusFormAberto.has(key);
    const statusFormHTML = formAberto ? `
        <div class="central-status-form">
            <select id="central-status-select-${key}" class="form-field">
                ${d.relatado === false ? `<option value="gerada" ${status === 'pendente' ? 'selected' : ''}>Gerada, ainda não relatada</option>` : ''}
                <option value="pendente" ${status === 'pendente' && d.relatado !== false ? 'selected' : ''}>Pendência relatada</option>
                <option value="resolvida" ${status === 'resolvida' ? 'selected' : ''}>Resolvida</option>
                <option value="encerrada" ${status === 'encerrada' ? 'selected' : ''}>Encerrada</option>
            </select>
            <input type="text" id="central-status-obs-${key}" class="form-field" placeholder="Observação (opcional)">
            <button type="button" class="actions-button is-success" onclick="confirmarAlteracaoStatusCentral('${oc._anotacaoId}', ${ocIdx}, ${divIdx})">Atualizar Status</button>
        </div>` : '';

    return `<div class="central-divergencia-bloco cdv">
        <div class="cdv-topo"><span class="cdv-tipo">${escRel(def ? def.label : (d.tipo || 'Ocorrência'))}</span><span class="central-status-badge status-${status}">${rotuloStatus}</span></div>
        ${chips ? `<div class="cdv-ctx">${chips}</div>` : ''}
        <div class="cdv-texto">${linhasHTML}</div>
        ${historicoHTML}
        <div class="cdv-rodape"><button type="button" class="central-status-toggle" onclick="toggleCentralStatusForm('${key}')">${formAberto ? 'Cancelar' : 'Alterar status'}</button></div>
        ${statusFormHTML}
    </div>`;
}

function renderCentralPedidoCompleto(pedido) {
    const cotacao = listaCotacoes.find(c => c.pedido === pedido);
    const nota = listaAnotacoes.find(a => a.pedido === pedido);

    document.getElementById('central-titulo-pedido').textContent = cotacao && cotacao.origem ? `${pedido} — ${cotacao.origem}` : pedido;
    // Fase 34: subtítulo com o essencial do pedido + resumo de entrega.
    // Fase 37: pedido sem cotação não tem o que separar em abas — mostra tudo junto, como antes.
    document.getElementById('screen-central-pedido').classList.toggle('central-sem-abas', !cotacao);
    const subEl = document.getElementById('central-subtitulo-pedido');
    if (subEl) {
        if (cotacao) {
            const nForn = (cotacao.fornecedores || []).length;
            subEl.innerHTML = `<div class="central-sub-linha">${nForn} fornecedor${nForn === 1 ? '' : 'es'}${cotacao.dataLimite ? ' · limite ' + formatarDataBRSimples(cotacao.dataLimite) : ''}</div><div class="nota-chips">${chipsResumoEntrega(resumoEntregaCotacao(cotacao))}</div><div class="actions-row" style="margin-top:8px">${htmlBotaoTodosChegaram(cotacao)}</div>`;
            subEl.style.display = 'block';
        } else { subEl.innerHTML = ''; subEl.style.display = 'none'; }
    }

    const headerCard = document.getElementById('central-header-card');
    const semCotacao = document.getElementById('central-sem-cotacao');
    if (cotacao) {
        headerCard.style.display = 'block';
        semCotacao.style.display = 'none';
        document.getElementById('central-origem').value = cotacao.origem || '';
        document.getElementById('central-data-pedido').value = cotacao.dataPedido || '';
        document.getElementById('central-data-limite').value = cotacao.dataLimite || '';
        document.getElementById('central-observacao-cotacao').value = cotacao.observacao || '';
    } else {
        headerCard.style.display = 'none';
        semCotacao.style.display = 'block';
    }

    // Todas as divergências de todas as ocorrências, achatadas, guardando os
    // índices reais (ocIdx/divIdx) pra alteração de status saber onde mexer,
    // e o id da anotação (pra Firestore) embutido em cada ocorrência.
    const todasDivergencias = [];
    (nota && nota.ocorrencias ? nota.ocorrencias : []).forEach((oc, ocIdx) => {
        const ocComId = { ...oc, _anotacaoId: nota.id };
        (oc.divergencias || []).forEach((d, divIdx) => todasDivergencias.push({ d, oc: ocComId, ocIdx, divIdx }));
    });

    const container = document.getElementById('central-fornecedores-container');

    if (cotacao) {
        const compItens = compararFontesPedido(pedido);
        const normNome = x => String(x || '').trim().toUpperCase();
        const fornecedoresHTML = (cotacao.fornecedores || []).map(f => {
            const nomeExibicao = nomeExibicaoFornecedor(f.razaoSocial, f.cnpj);
            const produtos = (cotacao.itens || []).filter(it => normalizarCnpj(it.cnpjFornecedor) === normalizarCnpj(f.cnpj));
            const divergenciasForn = todasDivergencias.filter(x => normalizarCnpj(x.oc.fornecedorCnpj) === normalizarCnpj(f.cnpj));
            const aberto = centralFornecedoresAbertos.has(f.cnpj);
            const compForn = compItens.filter(item => normalizarCnpj(item.cnpjFornecedor) === normalizarCnpj(f.cnpj));
            const chegada = (cotacao.chegadasPorFornecedor || {})[normalizarCnpj(f.cnpj)] || null;
            // Fase 31: status de entrega CALCULADO (XML do app + ERP + itens); a marca manual é exceção.
            const entrega = calcularEntregaFornecedorPedido(pedido, f, compForn);
            // 2.1.3: botões (chegou / abrir NF / associar NF) ficam FORA da parte que expande, sempre visíveis no card.
            const dadosEnt = dadosEntregaFornecedor(pedido, f, entrega);
            // 2.9.3: fechado, o cartão mostra só o cabeçalho e a barra de ações; faixa de entrega e números ficam no topo da parte que expande.
            // 2.22.6: botão para gerar de uma vez as auditorias de todas as ocorrências em aberto deste fornecedor (voltou ao cartão)
            const nLoteAud = compForn.filter(c => c.estado === 'detectada' && c.codProduto).length;
            const acoesLista = (dadosEnt ? dadosEnt.acoes : [acaoAssociarNf(pedido, f.cnpj)]).concat(nLoteAud > 1 ? [{ i: 'dir', t: `Gerar auditorias (${nLoteAud})`, fn: `registrarTodasDivergenciasDoFornecedor('${escRel(String(pedido))}','${escRel(String(f.cnpj))}')` }] : []);
            const acoesHTML = `<div class="ctl-bar cf-bar">${acoesLista.map(a => `<button type="button" onclick="event.stopPropagation(); ${a.fn}">${ICONES_CTRL[a.i] || ''}<span>${a.t}</span></button>`).join('')}</div>
                ${htmlPainelAssociarNf(pedido, f.cnpj)}`;
            const detalhesEntregaHTML = ((dadosEnt && dadosEnt.detalhes) || '') + htmlVinculadasNf(pedido, f.cnpj);

            // Fase 27: cada divergência da auditoria vai pra linha do PRIMEIRO
            // produto cujo nome bate EXATAMENTE (sem aproximação) com um dos
            // materiais dela. Sem correspondência exata (ou tipo sem material,
            // ex.: "fornecedor não entregou"), fica em "Outras divergências" —
            // nenhuma divergência some nem aparece duplicada.
            const divPorProduto = {};
            const divSoltas = [];
            divergenciasForn.forEach(x => {
                const nomes = materiaisDaDivergencia(x.d).map(m => normNome(m.produto || m.produtoPedido)).filter(Boolean);
                const codsRef = materiaisDaDivergencia(x.d).map(m => m.codProduto).filter(Boolean);
                const alvo = produtos.find(it => codsRef.includes(it.codProduto)) || (nomes.length ? produtos.find(it => nomes.some(n => nomesProdutoCombinam(n, it.nomeOficial || it.descricao || it.codProduto))) : null); // 2.0.9: mesmo critério da comparação
                if (alvo) (divPorProduto[alvo.codProduto] = divPorProduto[alvo.codProduto] || []).push(x);
                else divSoltas.push(x);
            });

            const produtosHTML = produtos.length
                ? produtos.map(it => {
                    const comp = compForn.find(c => c.codProduto === it.codProduto && (c.temNf || c.temErp || c.divergencias.length));
                    const divs = divPorProduto[it.codProduto] || [];
                    return renderLinhaProduto(it, `${f.cnpj}-${it.codProduto}`, {
                        comp, chegou: !!chegada, estado: (compForn.find(c => c.codProduto === it.codProduto) || {}).estado || 'nenhuma',
                        compHTML: comp ? renderComparacaoItemHTML(pedido, comp, true) : `<div class="central-item-vazio">${chegada ? 'Fornecedor marcado como já chegou (sem NF no app).' : 'Ainda sem NF/ERP para este item.'}</div>`,
                        divsHTML: divs.map(x => renderBlocoDivergencia(x.d, x.oc, x.ocIdx, x.divIdx)).join(''),
                        divsPendentes: divs.filter(x => (x.d.status || 'pendente') === 'pendente').length
                    });
                }).join('')
                : '<div class="central-item-vazio">Nenhum produto cotado registrado.</div>';

            const soltasHTML = divSoltas.length
                ? `<div class="central-secao-titulo">Outras divergências deste fornecedor</div>${divSoltas.map(x => renderBlocoDivergencia(x.d, x.oc, x.ocIdx, x.divIdx)).join('')}`
                : '';

            // 2.16.0: UMA contagem, pelo estado da ocorrência de cada item (nunca soma comparação + auditoria do mesmo problema).
            // Em aberto = detectada (sem relato: depende de você). Relatada tem o peso de resolvida: aparece, mas não acende o cartão.
            const estadosForn = compForn.map(c => c.estado);
            const nAbertas = compForn.filter(c => c.estado === 'detectada' && !c.soNaoChegou).length;
            const nNaoChegou = compForn.filter(c => c.estado === 'detectada' && c.soNaoChegou).length; // 2.19.1: "não chegou" não é divergência: conta à parte
            const arrivedSit = ['nf', 'erp', 'resolvido', 'parcial', 'parcial_relatada', 'erp_sem_quantidade'];
            const nChegaram = entrega && entrega.itens ? entrega.itens.filter(x => arrivedSit.includes(x.situacao)).length : 0;
            const chegadaTxt = (entrega && entrega.total && nChegaram > 0 && nChegaram < entrega.total) ? `${nChegaram} de ${entrega.total} itens chegaram` : '';
            const nRelatadas = estadosForn.filter(e => e === 'relatada').length + divSoltas.filter(x => (x.d.status || 'pendente') === 'pendente').length;
            const emErro = nAbertas > 0;
            const entregaOk = !!(entrega && (entrega.estado === 'completa' || entrega.estado === 'parcial_relatada')); // 2.16.1: parcial já chegou (falta relatada) pesa como entregue
            const classeFornecedor = emErro ? 'st-erro' : (entregaOk ? 'st-ok' : 'st-pend');
            const rot = entrega ? rotuloEntregaFornecedor(entrega) : null;
            const classeEntrega = rot ? (rot.classe === 'pronto' ? 'rs-ok' : rot.classe === 'pendente' ? 'rs-pend' : '') : '';

            // 2.9.0: cartão no padrão do app — iniciais, nome, status, itens/valor/pendências e (abaixo) as ações; o corpo continua recolhível.
            const valorCot = (typeof valorTotalCotacaoPorFornecedor === 'function') ? valorTotalCotacaoPorFornecedor(cotacao, f.cnpj) : 0;
            const stRot = emErro ? ['', 'Com pendência'] : (entregaOk ? ['ok', entrega.estado === 'parcial_relatada' ? 'Chegou (parcial)' : 'Entregue'] : ['m', 'Aguardando']);
            const pendTxt = [chegadaTxt, nAbertas ? `${nAbertas} divergência(s) em aberto` : '', nNaoChegou ? `${nNaoChegou} não chegou` : '', nRelatadas ? `${nRelatadas} pendência(s) relatada(s)` : ''].filter(Boolean).join(' · ');
            const cot3 = htmlResumoCotacoesFornecedor(pedido, produtos); // 2.19.2: itens do fornecedor que não atingiram o mínimo de cotações
            const faixaHTML = [dadosEnt && dadosEnt.curta, pendTxt].filter(Boolean).map(t => `<div class="ctl-inf cf-inf">${t}</div>`).join('') + cot3.detalhe;
            return `<div class="central-fornecedor${aberto ? ' aberto' : ''} ${classeFornecedor}" data-cnpj="${f.cnpj}">
                <div class="central-fornecedor-header" onclick="toggleCentralFornecedor('${f.cnpj}', this)">
                    <div class="ctl-av">${iniciaisControle(nomeExibicao)}</div>
                    <div class="cf-topo-info">
                        <div class="cf-nome">${nomeExibicao}</div>
                        ${f.cnpj ? `<div class="cf-cnpj">CNPJ ${formatarCnpjExibicao(f.cnpj)}</div>` : ''}
                        ${cot3.curto}
                    </div>
                    <span class="ctl-st ${emErro ? 'err ctl-link' : stRot[0]}"${emErro ? ` onclick="event.stopPropagation(); irParaDivergenciaCartao('${f.cnpj}')"` : ''}>${stRot[1]}</span>
                    <i class="fa-solid fa-chevron-right"></i>
                </div>
                ${acoesHTML}
                <div class="central-colapso"><div class="central-colapso-inner"><div class="central-fornecedor-body">
                    ${faixaHTML}
                    <div class="cf-tiles"><div><span>Itens</span><strong>${(entrega && entrega.total && nChegaram > 0 && nChegaram < entrega.total) ? nChegaram + '/' + produtos.length : produtos.length}</strong></div><div><span>Valor cotado</span><strong>${valorCot ? 'R$ ' + formatarValorMonetarioBR(valorCot) : '—'}</strong></div><div${(nAbertas + nRelatadas) ? ` class="ctl-link" onclick="irParaDivergenciaCartao('${f.cnpj}')"` : ''}><span>Em aberto</span><strong class="${nAbertas ? 'e' : ''}">${nAbertas}</strong></div></div>
                    ${detalhesEntregaHTML ? `<div class="cf-detalhes">${detalhesEntregaHTML}</div>` : ''}
                    ${produtosHTML}
                    ${soltasHTML}
                </div></div></div>
            </div>`;
        }).join('');

        const semFornecedor = todasDivergencias.filter(x => !x.oc.fornecedorCnpj);
        const abertoSem = centralFornecedoresAbertos.has('_sem_cnpj');
        const semFornecedorHTML = semFornecedor.length ? `<div class="central-fornecedor${abertoSem ? ' aberto' : ''}">
            <div class="central-fornecedor-header cf-simples" onclick="toggleCentralFornecedor('_sem_cnpj', this)">
                <div class="cf-topo-info"><div class="cf-nome">Outras ocorrências</div><div class="cf-cnpj">sem fornecedor identificado na cotação</div></div>
                <i class="fa-solid fa-chevron-right"></i>
            </div>
            <div class="central-colapso"><div class="central-colapso-inner"><div class="central-fornecedor-body">
                ${semFornecedor.map(x => renderBlocoDivergencia(x.d, x.oc, x.ocIdx, x.divIdx)).join('')}
            </div></div></div>
        </div>` : '';

        container.innerHTML = htmlItensForaDoPedido(pedido) + fornecedoresHTML + semFornecedorHTML; // 2.3.0
    } else if (nota) {
        // Sem cotação cadastrada, mas já existem ocorrências registradas (ex:
        // auditorias antigas de antes da cotação existir) — mostra tudo junto,
        // sem agrupamento por fornecedor (não há CNPJ pra agrupar por).
        container.innerHTML = todasDivergencias.length
            ? todasDivergencias.map(x => renderBlocoDivergencia(x.d, x.oc, x.ocIdx, x.divIdx)).join('')
            : '<div class="central-item-vazio">Nenhuma ocorrência registrada ainda.</div>';
    } else {
        container.innerHTML = '';
    }

    document.getElementById('central-btn-texto-livre').style.display = nota ? '' : 'none';

    // Anotação embutida no próprio contexto do pedido (correção desta rodada):
    // mesma anotação/estrutura de sempre (anotacoesTextoCollection, casada
    // por `pedido`), só que exibida e editável aqui, sem precisar navegar pra
    // Anotações. Guarda contra sobrescrever o que a pessoa está digitando: só
    // substitui o conteúdo do campo se ele não estiver com foco no momento.
    centralAnotacaoId = nota ? nota.id : null;
    const anotCard = document.getElementById('central-anotacao-card');
    const anotVazia = document.getElementById('central-anotacao-vazia');
    if (anotCard && anotVazia) {
        if (nota) {
            anotCard.style.display = 'block';
            anotVazia.style.display = 'none';
            const campo = document.getElementById('central-anotacao-conteudo');
            if (campo && document.activeElement !== campo) campo.innerHTML = nota.conteudo || '';
        } else {
            anotCard.style.display = 'none';
            anotVazia.style.display = 'block';
        }
    }

}

let centralAnotacaoId = null;
let autoSaveAnotacaoInlineCentralTimeout = null;

function agendarSalvarAnotacaoInlineCentral() {
    clearTimeout(autoSaveAnotacaoInlineCentralTimeout);
    autoSaveAnotacaoInlineCentralTimeout = setTimeout(salvarAnotacaoInlineCentral, 1200);
}

async function salvarAnotacaoInlineCentral() {
    if (!centralAnotacaoId) return;
    const campo = document.getElementById('central-anotacao-conteudo');
    if (!campo) return;
    try {
        await anotacoesTextoCollection.doc(centralAnotacaoId).update({ conteudo: campo.innerHTML, atualizadoEm: new Date().toISOString() });
    } catch (e) {
        console.error('Erro ao salvar anotação inline da Central:', e);
    }
}

// Reaproveita a mesma criação usada na cotação (criarOuAtualizarAnotacaoDaCotacao)
// — sem estrutura de dados nova. Preenche o campo na hora, sem esperar o
// listener em tempo real, pra já aparecer editável assim que criada.
async function criarAnotacaoInlineCentral() {
    if (!centralPedidoAtual) return;
    const cotacao = listaCotacoes.find(c => c.pedido === centralPedidoAtual);
    const origem = cotacao ? cotacao.origem : '';
    const dataPedido = cotacao ? cotacao.dataPedido : '';
    const dataLimite = cotacao ? cotacao.dataLimite : '';
    const fornecedores = cotacao ? cotacao.fornecedores : [];
    try {
        const id = await criarOuAtualizarAnotacaoDaCotacao(centralPedidoAtual, origem, dataPedido, dataLimite, fornecedores);
        if (!id) return toast('✕ Erro ao criar anotação.');
        centralAnotacaoId = id;
        document.getElementById('central-anotacao-card').style.display = 'block';
        document.getElementById('central-anotacao-vazia').style.display = 'none';
        document.getElementById('central-anotacao-conteudo').innerHTML = montarCabecalhoAnotacaoCotacao(centralPedidoAtual, origem, dataPedido, dataLimite, fornecedores);
    } catch (e) {
        console.error('Erro ao criar anotação do pedido:', e);
        toast('✕ Erro ao criar anotação.');
    }
}

// Produto sempre mostra o que realmente veio do XML — nunca inventa uma
// descrição. Quando o fornecedor não preencheu o campo de descrição (existe
// no XML real: alguns itens vêm com <Comentario></Comentario> vazio),
// mostra isso como ausência de dado, nunca como se fosse o nome do produto,
// e o código do fornecedor fica sempre visível (base pra associação futura
// de código externo → interno).
// Reconstrói a cotação com fidelidade total (regra definitiva combinada) —
// nunca usa observação/fabricante/código como substituto do nome oficial.
// Nome oficial só existe depois que o relatório do SmartCompras for colado
// e cruzado (código + CNPJ); até lá, fica marcado como pendente de
// complementação, nunca escondido nem inventado.
let centralProdutosExpandidos = new Set();
let centralAssociacaoBuscaAberta = new Set();

function renderAssociacaoSpDataWidget(it, chaveUnica) {
    if (!it.codProduto) return '';
    const chaveWidget = `assoc-${chaveUnica}`;
    const associacao = listaAssociacoesSpData.find(a => a.codigoSmartCompras === it.codProduto);
    const buscaAberta = centralAssociacaoBuscaAberta.has(chaveWidget);

    if (associacao) {
        const produto = listaProdutosSpData.find(p => p.codigo === associacao.spDataCodigo);
        const linha = produto ? `${produto.codigo} — ${produto.nome} — ${produto.unidade}` : `${associacao.spDataCodigo} (produto não encontrado no cadastro atual)`;
        return `<div class="central-spdata-linha">
            <span><strong>SP Data:</strong> ${linha}</span>
            <button type="button" class="central-status-toggle" onclick="event.stopPropagation(); toggleBuscaAssociacaoSpData('${chaveWidget}')">${buscaAberta ? 'Cancelar' : 'Corrigir SP Data'}</button>
        </div>${buscaAberta ? renderBuscaAssociacaoSpData(it, chaveWidget) : ''}`;
    }

    return `<div class="central-spdata-linha central-item-sem-desc">
        <span>SP Data: não associado</span>
        <button type="button" class="central-status-toggle" onclick="event.stopPropagation(); toggleBuscaAssociacaoSpData('${chaveWidget}')">${buscaAberta ? 'Cancelar' : 'Associar SP Data'}</button>
    </div>${buscaAberta ? renderBuscaAssociacaoSpData(it, chaveWidget) : ''}`;
}
function toggleBuscaAssociacaoSpData(chaveWidget) {
    if (centralAssociacaoBuscaAberta.has(chaveWidget)) centralAssociacaoBuscaAberta.delete(chaveWidget);
    else centralAssociacaoBuscaAberta.add(chaveWidget);
    // Este widget é reaproveitado tanto na Central do Pedido quanto na
    // Entrada de NF (associação SP Data direto na tela, sem sair pra
    // Cotações) — re-renderiza só o(s) contexto(s) realmente ativo(s).
    if (centralPedidoAtual) renderCentralPedidoCompleto(centralPedidoAtual);
    if (nfeInfoAtual) renderAssociacaoCotacaoXml();
}
// Sugestões iniciais aparecem ao abrir (baseadas no nome oficial do item, se
// houver); busca manual atualiza só a lista de resultados via DOM direto
// (não re-renderiza a Central inteira), senão o campo de texto perderia o
// foco a cada letra digitada.
function renderBuscaAssociacaoSpData(it, chaveWidget) {
    const sugestoesIniciais = it.nomeOficial ? buscarSugestoesSpData(it.nomeOficial) : [];
    const listaInicialHTML = sugestoesIniciais.length
        ? sugestoesIniciais.slice(0, 8).map(p => `<div class="central-spdata-opcao" onclick="event.stopPropagation(); confirmarAssociacaoSpData('${it.codProduto}', '${p.codigo}')"><strong>${p.codigo}</strong> — ${p.nome} — ${p.unidade}</div>`).join('')
        : '<div class="central-item-vazio">Nenhuma sugestão automática — busque manualmente pelo nome ou código.</div>';
    return `<div class="central-spdata-busca" onclick="event.stopPropagation()">
        <input type="text" class="form-field" placeholder="Buscar por nome ou código..." oninput="atualizarBuscaAssociacaoSpData('${chaveWidget}', '${it.codProduto}', this.value)">
        <div class="central-spdata-opcoes" id="spdata-resultados-${chaveWidget}">${listaInicialHTML}</div>
    </div>`;
}
function atualizarBuscaAssociacaoSpData(chaveWidget, codigoItem, texto) {
    const container = document.getElementById(`spdata-resultados-${chaveWidget}`);
    if (!container) return;
    const candidatos = texto.trim() ? buscarSugestoesSpData(texto) : [];
    container.innerHTML = candidatos.length
        ? candidatos.slice(0, 8).map(p => `<div class="central-spdata-opcao" onclick="event.stopPropagation(); confirmarAssociacaoSpData('${codigoItem}', '${p.codigo}')"><strong>${p.codigo}</strong> — ${p.nome} — ${p.unidade}</div>`).join('')
        : '<div class="central-item-vazio">Nenhum produto encontrado.</div>';
}

function renderLinhaProduto(it, chaveUnica, ctx) {
    const nomeOficialSmartCompras = it.nomeOficial ? upAud(it.nomeOficial) : null;
    const observacao = it.descricao && it.descricao !== '---' ? upAud(it.descricao) : '';
    const marca = it.fabricante && it.fabricante !== '---' ? it.fabricante : '';
    const expandido = centralProdutosExpandidos.has(chaveUnica);

    // Depois que existe associação confirmada com o SP Data, a identidade
    // interna (SP Data) passa a ser a identificação PRINCIPAL exibida na
    // lista — nada do SmartCompras é apagado, só deixa de ser o título e
    // passa pros detalhes expandidos (ver detalhesHTML abaixo).
    const associacaoSpData = it.codProduto ? listaAssociacoesSpData.find(a => a.codigoSmartCompras === it.codProduto) : null;
    const produtoSpData = associacaoSpData ? listaProdutosSpData.find(p => p.codigo === associacaoSpData.spDataCodigo) : null;

    // Relatório de fornecedores ganhadores (fonte complementar à cotação):
    // mostra quantos fornecedores realmente cotaram este item específico —
    // é um fato objetivo, nunca decide recurso/pagamento sozinho.
    const relatorioGanhadoresPedido = centralPedidoAtual ? listaRelatorioGanhadores.find(r => r.pedido === centralPedidoAtual) : null;
    const itemGanhadores = relatorioGanhadoresPedido && it.codProduto ? relatorioGanhadoresPedido.itens.find(g => g.codigo === it.codProduto) : null;
    const participantesResumo = itemGanhadores ? ` · ${itemGanhadores.participantes} fornecedor(es) cotaram` : '';
    const participantesDetalheHTML = itemGanhadores
        ? `<div>Fornecedores que cotaram este item: <strong>${itemGanhadores.participantes}</strong>${itemGanhadores.participantes >= minimoFornecedoresCC() ? ' ✓' : ` (menos de ${minimoFornecedoresCC()} participantes)`}</div><div>Vencedor: ${itemGanhadores.fornecedorVencedor ? itemGanhadores.fornecedorVencedor.nome : '<em>não identificado</em>'}</div>${itemGanhadores.empresas.length ? `<div class="txt-aux">Participantes: ${itemGanhadores.empresas.map(e => e.nome).join(', ')}</div>` : ''}`
        : '';

    const tituloHTML = nomeOficialSmartCompras
        ? `<div class="central-item-desc-linha">${nomeOficialSmartCompras}</div>`
        : ((nomeProv) => nomeProv
            ? `<div class="central-item-desc-linha">${escRel(nomeProv)} <small class="central-item-sem-desc">(nome lançado no ERP; o oficial vem do relatório do SmartCompras)</small></div>`
            : `<div class="central-item-desc-linha central-item-sem-desc">Nome oficial: pendente de complementação (importe o relatório do SmartCompras)</div>`)(typeof nomeProvisorioItemCotacao === 'function' ? nomeProvisorioItemCotacao(centralPedidoAtual, it) : null);
    // SP Data sempre visível, mas como linha SECUNDÁRIA — nunca substitui o
    // nome real da cotação (já foi assim antes e causou associação errada:
    // nomes do SP Data podem vir cortados/parecidos e escondiam o nome real).
    const spDataSubtituloHTML = produtoSpData ? `<div class="central-item-meta">SP Data ${produtoSpData.codigo} — ${produtoSpData.nome}</div>` : '';

    // Recurso confirmado na entrada da NF/XML (Parte 2/4 da correção) — só
    // exibição, nunca uma ação de escolher aqui.
    const recursoItem = (centralPedidoAtual && it.codProduto) ? (() => {
        const c = listaCotacoes.find(x => x.pedido === centralPedidoAtual);
        return c && c.recursosPorItem ? c.recursosPorItem[it.codProduto] : null;
    })() : null;
    // 2.17.1: card do item reorganizado em blocos (Produto · Quantidade e valores · Cotação e recurso · SP Data). O recurso é lido
    // da própria cotação (nº de fornecedores que cotaram); a NF só o confirma/grava — por isso não aparece mais "ainda não confirmado"
    // ao lado de "7 fornecedores cotaram".
    const cotItem = centralPedidoAtual ? listaCotacoes.find(x => x.pedido === centralPedidoAtual) : null;
    const recursoPelaCotacao = (cotItem && it.codProduto) ? recursoEsperadoPelaCotacao(cotItem, it.codProduto) : '';
    const minCC = minimoFornecedoresCC();
    const nPart = itemGanhadores ? itemGanhadores.participantes : null;
    const rec = (rotulo, valor, selo, dica) => `<div class="cdet-rec"><div class="cdet-rec-linha"><span class="cdet-k">${rotulo}</span><strong>${valor}</strong>${selo ? `<span class="xml-item-badge ${selo[0]}">${selo[1]}</span>` : ''}</div>${dica ? `<div class="cdet-dica">${dica}</div>` : ''}</div>`;
    let recursoHTML = '';
    if (it.codProduto) {
        if (recursoItem) {
            recursoHTML = rec('Recurso', escRel(recursoItem), ['pronto', '✓ Confirmado na NF'], (recursoPelaCotacao && recursoPelaCotacao !== recursoItem) ? `A cotação indicava ${escRel(recursoPelaCotacao)}; vale o que foi confirmado na NF.` : '');
        } else if (recursoPelaCotacao) {
            recursoHTML = rec('Recurso', escRel(recursoPelaCotacao), ['neutro', 'Pela cotação'], `${nPart != null ? nPart + ' fornecedor(es) cotaram' : 'Regra da cotação'}. Fica gravado no pedido quando a NF for salva.`);
        } else if (nPart != null && nPart < minCC) {
            recursoHTML = rec('Recurso', 'a definir', ['pendente', 'Escolher na NF'], `Só ${nPart} fornecedor(es) cotaram (mínimo ${minCC} para C/C): escolha o recurso na entrada da NF.`);
        } else {
            recursoHTML = rec('Recurso', 'a definir', ['neutro', 'Na entrada da NF'], 'O recurso será definido na entrada da NF.');
        }
    }
    const cotacaoBlocoHTML = itemGanhadores
        ? `<div class="cdet-cot"><div class="cdet-rec-linha"><span class="cdet-k">Cotaram este item</span><strong>${itemGanhadores.participantes}</strong>${itemGanhadores.participantes >= minCC ? '<span class="xml-item-badge pronto">✓ Atingiu o mínimo</span>' : `<span class="xml-item-badge pendente">Abaixo de ${minCC}</span>`}</div>
            <div class="cdet-linha"><span class="cdet-k">Vencedor</span><span>${itemGanhadores.fornecedorVencedor ? escRel(itemGanhadores.fornecedorVencedor.nome) : '<em>não identificado</em>'}</span></div>
            ${itemGanhadores.empresas.length ? `<details class="cdet-part"><summary>Ver os ${itemGanhadores.empresas.length} participantes</summary><div class="txt-aux">${itemGanhadores.empresas.map(e => escRel(e.nome)).join(', ')}</div></details>` : ''}</div>`
        : '';
    const moeda = v => { const n = Number(String(v).replace(/\./g, '').replace(',', '.')); const bruto = Number(String(v).replace(',', '.')); const x = Number.isFinite(bruto) ? bruto : n; return Number.isFinite(x) ? 'R$ ' + formatValorBR(x) : 'R$ ' + v; };
    const numeros = [it.quantidade ? ['Quantidade', it.quantidade] : null, it.precoUnitario ? ['Valor unitário', moeda(it.precoUnitario)] : null, it.precoTotal ? ['Valor total', moeda(it.precoTotal)] : null].filter(Boolean);

    const detalhesHTML = `<div class="central-item-detalhes cdet">
        <div class="cdet-bloco"><div class="cdet-tit">Produto</div>
            ${nomeOficialSmartCompras ? `<div class="cdet-nome">${nomeOficialSmartCompras}</div>` : ''}
            <div class="cdet-linha-meta">${[it.codProduto ? `Cód. SmartCompras ${it.codProduto}` : '', marca ? `Marca ${marca}` : '', it.embalagem ? `Emb. ${it.embalagem}` : ''].filter(Boolean).map(x => `<span>${escRel(x)}</span>`).join('')}</div>
            ${observacao ? `<div class="cdet-dica">Descrição original: ${observacao}</div>` : ''}
        </div>
        ${numeros.length ? `<div class="cdet-numeros">${numeros.map(([k, v]) => `<div><span class="cdet-k">${k}</span><strong>${escRel(String(v))}</strong></div>`).join('')}</div>` : ''}
        ${(cotacaoBlocoHTML || recursoHTML) ? `<div class="cdet-bloco"><div class="cdet-tit">Cotação e recurso</div>${cotacaoBlocoHTML}${recursoHTML}</div>` : ''}
        ${renderAssociacaoSpDataWidget(it, chaveUnica)}
    </div>`;

    const resumoMeta = [it.codProduto ? `Cód. ${it.codProduto}` : '', it.quantidade ? `Qtd ${it.quantidade}` : ''].filter(Boolean).join(' · ');

    // Fase 27: linha única recolhível — cabeçalho (nome, SP Data, status) e,
    // ao abrir, cotação + comparação Cotação × NF × ERP + divergências da
    // auditoria do MESMO item. Abre/fecha por classe (sem redesenhar a tela).
    const c = ctx || {};
    // 2.16.0: UMA etiqueta por item, pelo estado da ocorrência (a divergência detectada e a auditoria do mesmo item deixam de ser dois selos).
    const estadoItem = c.estado || (c.comp ? c.comp.estado : 'nenhuma');
    const seloEstado = seloEstadoOcorrencia(estadoItem, c.comp ? c.comp.divergencias.length : 0, c.comp ? c.comp.soNaoChegou : false);
    const badges = seloEstado
        || (c.comp ? ((!c.comp.temNf && c.comp.temErp) ? `<span class="xml-item-badge pronto">Lançado no ERP</span>`
            : `<span class="xml-item-badge pronto">✓ Confere</span>`) : (c.chegou ? `<span class="xml-item-badge pronto">Chegou</span>` : ''));
    return `<div class="central-item-linha central-prod${expandido ? ' aberto' : ''}">
        <div class="central-prod-cab" onclick="toggleCentralProduto('${chaveUnica}', this)">
            ${tituloHTML}
            ${spDataSubtituloHTML}
            <div class="central-item-meta"><span>${resumoMeta}${participantesResumo}</span><span class="central-prod-badges">${badges}<i class="fa-solid fa-chevron-down central-item-chevron"></i></span></div>
        </div>
        <div class="central-colapso"><div class="central-colapso-inner">
            ${detalhesHTML}
            ${c.compHTML ? `<div class="central-secao-titulo">Comparação Cotação × NF × ERP</div>${c.compHTML}` : ''}
            ${c.divsHTML ? `<div class="central-secao-titulo">Divergências (auditoria)</div>${c.divsHTML}` : ''}
        </div></div>
    </div>`;
}
function toggleCentralProduto(chave, el) {
    const abrir = !centralProdutosExpandidos.has(chave);
    if (abrir) centralProdutosExpandidos.add(chave); else centralProdutosExpandidos.delete(chave);
    const linha = el && el.closest ? el.closest('.central-item-linha') : null;
    if (linha) linha.classList.toggle('aberto', abrir); // só troca a classe: animação suave, sem redesenhar
    else renderCentralPedidoCompleto(centralPedidoAtual);
}

function toggleCentralFornecedor(cnpj, el) {
    const abrir = !centralFornecedoresAbertos.has(cnpj);
    if (abrir) centralFornecedoresAbertos.add(cnpj); else centralFornecedoresAbertos.delete(cnpj);
    const card = el && el.closest ? el.closest('.central-fornecedor') : null;
    if (card) card.classList.toggle('aberto', abrir);
    else renderCentralPedidoCompleto(centralPedidoAtual);
}
function toggleCentralStatusForm(key) {
    if (centralStatusFormAberto.has(key)) centralStatusFormAberto.delete(key);
    else centralStatusFormAberto.add(key);
    renderCentralPedidoCompleto(centralPedidoAtual);
}

async function confirmarAlteracaoStatusCentral(anotacaoId, ocIdx, divIdx) {
    const key = `${ocIdx}-${divIdx}`;
    const select = document.getElementById(`central-status-select-${key}`);
    const obsInput = document.getElementById(`central-status-obs-${key}`);
    const novoStatus = select.value;
    const observacao = obsInput.value.trim();

    const nota = listaAnotacoes.find(a => a.id === anotacaoId);
    if (!nota) return;
    // Clona profundamente antes de mexer — nunca muta o array em memória
    // direto, só depois que o Firestore confirmar a escrita.
    const ocorrencias = JSON.parse(JSON.stringify(nota.ocorrencias || []));
    const oc = ocorrencias[ocIdx];
    if (!oc || !oc.divergencias || !oc.divergencias[divIdx]) return;
    const d = oc.divergencias[divIdx];
    const statusAnterior = d.status || 'pendente';
    if (novoStatus === 'gerada') { d.status = 'pendente'; d.relatado = false; } // volta a "gerada, ainda não relatada"
    else { d.status = novoStatus; if (novoStatus === 'pendente') d.relatado = true; } // escolher "Pendência relatada" é o ato de relatar
    if (!d.historico) d.historico = [];
    // HISTÓRICO NUNCA É APAGADO — só acrescenta uma entrada nova. O texto
    // gerado/salvo na anotação continua exatamente como estava.
    const tipoEntrada = novoStatus === 'resolvida' ? 'resolucao' : novoStatus === 'encerrada' ? 'encerramento' : novoStatus === 'gerada' ? 'geracao' : (statusAnterior === 'pendente' ? 'relato' : 'reabertura');
    d.historico.push({ tipo: tipoEntrada, data: dataLocalISO(), observacao });

    try {
        await anotacoesTextoCollection.doc(anotacaoId).update({ ocorrencias, atualizadoEm: new Date().toISOString() });
        toast('✓ Status atualizado.');
        centralStatusFormAberto.delete(key);
        renderCentralPedidoCompleto(centralPedidoAtual);
    } catch (e) {
        console.error('Erro ao atualizar status da divergência:', e);
        toast('✕ Erro ao atualizar status.');
    }
}

// Origem/Data do Pedido/Data Limite/Observação editáveis direto na Central
// (igual ao Gerenciador de NF: abrir, editar, salvar, sem trocar de tela) —
// grava só esses campos em cotacoes/{pedido}, nunca mexe em fornecedores/
// itens (esses continuam vindo só da importação do XML ou cadastro manual).
async function salvarCabecalhoCotacaoCentral() {
    if (!centralPedidoAtual) return;
    const dados = {
        origem: document.getElementById('central-origem').value,
        dataPedido: document.getElementById('central-data-pedido').value,
        dataLimite: document.getElementById('central-data-limite').value,
        observacao: document.getElementById('central-observacao-cotacao').value.trim(),
        atualizadoEm: new Date().toISOString()
    };
    try {
        await cotacoesCollection.doc(centralPedidoAtual).set(dados, { merge: true });
        const nota = listaAnotacoes.find(a => a.pedido === centralPedidoAtual);
        if (nota) {
            const novoTitulo = dados.origem ? `${centralPedidoAtual} - ${dados.origem}` : centralPedidoAtual;
            if (novoTitulo !== nota.titulo) await anotacoesTextoCollection.doc(nota.id).update({ titulo: novoTitulo });
        }
        toast('✓ Salvo.');
        // Sem isso, o título/dados na tela ficavam desatualizados até a
        // próxima ação que disparasse um re-render — o listener do Firestore
        // não está amarrado a essa tela.
        renderCentralPedidoCompleto(centralPedidoAtual);
    } catch (e) {
        console.error('Erro ao salvar dados do pedido:', e);
        toast('✕ Erro ao salvar.');
    }
}

function iniciarAuditoriaDoPedidoCentral() {
    const pedido = centralPedidoAtual;
    abrirNovaAuditoria();
    document.getElementById('aud-pedido').value = pedido;
    buscarCotacaoParaAuditoria();
}

function abrirTextoLivreDoPedidoCentral() {
    const nota = listaAnotacoes.find(a => a.pedido === centralPedidoAtual);
    if (!nota) return toast('Nenhuma anotação encontrada para este pedido ainda.');
    voltarAnotacaoEditorParaCentral = centralPedidoAtual;
    abrirAnotacao(nota.id, true);
}

function voltarParaListaAnotacoes() {
    if (voltarAnotacaoEditorParaCentral) {
        const pedido = voltarAnotacaoEditorParaCentral;
        voltarAnotacaoEditorParaCentral = null;
        abrirCentralPedido(pedido);
        return;
    }
    switchToScreen('screen-anotacoes', 'Anotações');
}

let autoSaveAnotacaoTimeout = null;
function atualizarTituloCabecalhoAnotacao() {   // o título branco do topo acompanha o que está escrito (e o que foi salvo)
    const h = document.getElementById('main-header-title'), t = document.getElementById('anotacao-titulo'), tela = document.getElementById('screen-anotacoes-editor');
    if (h && t && tela && tela.classList.contains('active')) h.textContent = t.value.trim() || (anotacaoAtualId ? 'Sem título' : 'Nova Anotação');
}
function agendarAutoSaveAnotacao() {
    atualizarEstadoToolbarAnotacao(); atualizarTituloCabecalhoAnotacao();
    clearTimeout(autoSaveAnotacaoTimeout);
    autoSaveAnotacaoTimeout = setTimeout(() => salvarAnotacaoAtual(false), 1200);
}

async function salvarAnotacaoAtual(mostrarToast) {
    const tituloEl = document.getElementById('anotacao-titulo');
    const corpoEl = document.getElementById('anotacao-corpo');
    if (!tituloEl || !corpoEl) return;

    const titulo = tituloEl.value.trim();
    const conteudo = corpoEl.innerHTML;

    // Nada digitado ainda numa anotação nova: não cria lixo no banco.
    if (!anotacaoAtualId && !titulo && !stripHtmlAnotacao(conteudo)) {
        if (mostrarToast) toast('Nada para salvar.');
        return;
    }

    const dados = {
        titulo: titulo || 'Sem título',
        conteudo,
        espacamentoLinha: editorEspacamentoLinhaAtual,
        paragrafoCompacto: editorParagrafoCompactoAtual,
        atualizadoEm: new Date().toISOString()
    };

    try {
        if (anotacaoAtualId) {
            await anotacoesTextoCollection.doc(anotacaoAtualId).update(dados);
        } else {
            dados.criadoEm = dados.atualizadoEm;
            const ref = await anotacoesTextoCollection.add(dados);
            anotacaoAtualId = ref.id;
        }
        atualizarTituloCabecalhoAnotacao();
        if (mostrarToast) toast('✓ Anotação salva!');
    } catch (e) {
        console.error('Erro ao salvar anotação:', e);
        if (mostrarToast) toast('✕ Erro ao salvar anotação.');
    }
}

// Estilo Apple Notas: "✓" no topo conclui (salva e volta) e "⋯" abre as ações da anotação (copiar, colar, limpar, excluir)
async function concluirAnotacao() {
    fecharMenuNota(); fecharPopoversRte(); clearTimeout(autoSaveAnotacaoTimeout);
    if (document.activeElement && typeof document.activeElement.blur === 'function') document.activeElement.blur();
    await salvarAnotacaoAtual(true);
    voltarParaListaAnotacoes();
}
// Regulagem da altura da barra de formatação (fica no menu ⋯): − desce, + sobe, de 4 em 4 px; vale já com o teclado aberto.
function atualizarValorAlturaBarra() { const el = document.getElementById('nota-altura-valor'); if (el && typeof window.rteBarrinhaAtual === 'function') el.textContent = window.rteBarrinhaAtual() + ' px'; }
function ajustarAlturaBarraNotas(delta) {
    const atual = typeof window.rteBarrinhaAtual === 'function' ? window.rteBarrinhaAtual() : 0;
    const novo = Math.max(-24, Math.min(90, atual + delta));
    try { localStorage.setItem('rteBarrinha', String(novo)); } catch (e) {}
    atualizarValorAlturaBarra();
    if (typeof window.posicionarBarraDeFormatacao === 'function') window.posicionarBarraDeFormatacao();
}
function fecharMenuNota() { const m = document.getElementById('nota-menu'); if (m) m.style.display = 'none'; }
function toggleMenuNota(ev) { if (ev) ev.stopPropagation(); const m = document.getElementById('nota-menu'); if (!m) return; fecharPopoversRte(); m.style.display = m.style.display === 'none' ? 'block' : 'none'; atualizarValorAlturaBarra(); }
function menuNotaAcao(acao) {
    fecharMenuNota();
    if (acao === 'copiar') copiarTextoAnotacao(); else if (acao === 'colar') colarTextoAnotacao(); else if (acao === 'limpar') limparTextoAnotacao(); else if (acao === 'excluir') excluirAnotacaoAtual();
}
document.addEventListener('click', (e) => { if (!e.target.closest('#nota-menu')) fecharMenuNota(); });

async function copiarTextoAnotacao() {
    const corpoEl = document.getElementById('anotacao-corpo');
    const texto = corpoEl ? corpoEl.innerText.trim() : '';
    if (!texto) return toast('Nada para copiar.');
    await navigator.clipboard.writeText(texto);
    toast('✓ Texto copiado!');
}

async function colarTextoAnotacao() {
    const corpoEl = document.getElementById('anotacao-corpo');
    if (!corpoEl) return;
    try {
        const texto = await navigator.clipboard.readText();
        if (!texto) return toast('Área de transferência vazia.');
        corpoEl.focus();
        document.execCommand('insertText', false, texto);
        agendarAutoSaveAnotacao();
        toast('✓ Texto colado!');
    } catch (e) {
        console.error('Erro ao colar:', e);
        toast('✕ Não foi possível colar. Verifique a permissão de área de transferência.');
    }
}

function limparTextoAnotacao() {
    const corpoEl = document.getElementById('anotacao-corpo');
    if (!corpoEl || !stripHtmlAnotacao(corpoEl.innerHTML)) return toast('Já está vazio.');
    showConfirmModal({
        title: 'Limpar Texto',
        message: 'Isso vai apagar todo o texto desta anotação. O título é mantido.',
        confirmText: 'Limpar',
        confirmClass: 'danger',
        onConfirm: () => {
            corpoEl.innerHTML = '';
            agendarAutoSaveAnotacao();
            toast('✓ Texto limpo.');
        }
    });
}

function excluirAnotacaoAtual() {
    if (!anotacaoAtualId) {
        // anotação nova, ainda não salva - só descarta e volta pra lista sem criar nada
        clearTimeout(autoSaveAnotacaoTimeout);
        document.getElementById('anotacao-titulo').value = '';
        document.getElementById('anotacao-corpo').innerHTML = '';
        switchToScreen('screen-anotacoes', 'Anotações');
        return;
    }
    showConfirmModal({
        title: 'Excluir Anotação',
        message: 'Deseja excluir esta anotação permanentemente?',
        confirmText: 'Excluir',
        confirmClass: 'danger',
        onConfirm: async () => {
            try {
                clearTimeout(autoSaveAnotacaoTimeout);
                await anotacoesTextoCollection.doc(anotacaoAtualId).delete();
                anotacaoAtualId = null;
                document.getElementById('anotacao-titulo').value = '';
                document.getElementById('anotacao-corpo').innerHTML = '';
                toast('🗑️ Anotação excluída.');
                switchToScreen('screen-anotacoes', 'Anotações');
            } catch (e) {
                console.error('Erro ao excluir anotação:', e);
                toast('✕ Erro ao excluir.');
            }
        }
    });
}

// Formatação de texto rico (negrito, itálico, títulos, listas). execCommand
// ainda funciona bem pra esses comandos básicos em todos os navegadores atuais,
// apesar de "deprecated" — é a forma mais simples de dar edição tipo
// Word/Notion sem precisar de uma biblioteca externa pesada.
function formatarTextoAnotacao(comando, valor) {
    document.getElementById('anotacao-corpo').focus();
    document.execCommand(comando, false, valor || null);
    agendarAutoSaveAnotacao();
    atualizarEstadoToolbarAnotacao();
}

// --- Estado visual da toolbar (negrito/itálico/sublinhado/bloco ativos, e
// undo/redo habilitados) — precisa refletir o estado REAL do cursor/seleção
// a cada momento, não um valor fixo marcado uma vez. Atualiza via
// selectionchange (filtrado pro editor de anotações), a cada digitação, e
// logo depois de qualquer comando de formatação disparado pelos botões.
function atualizarEstadoToolbarAnotacao() {
    const editor = document.getElementById('anotacao-corpo');
    if (!editor) return;
    ['bold', 'italic', 'underline'].forEach(cmd => {
        const btn = document.querySelector(`.rte-toolbar button[data-cmd="${cmd}"]`);
        if (!btn) return;
        try { btn.classList.toggle('active', document.queryCommandState(cmd)); } catch (e) {}
    });
    let blocoAtual = '';
    try { blocoAtual = (document.queryCommandValue('formatBlock') || '').toUpperCase(); } catch (e) {}
    document.querySelectorAll('.rte-toolbar button[data-block]').forEach(btn => {
        const alvo = btn.dataset.block;
        const ehParagrafoPadrao = alvo === 'P' && (blocoAtual === '' || blocoAtual === 'DIV' || blocoAtual === 'P');
        btn.classList.toggle('active', blocoAtual === alvo || ehParagrafoPadrao);
    });
    ['undo', 'redo'].forEach(cmd => {
        const btn = document.querySelector(`.rte-toolbar button[data-cmd="${cmd}"]`);
        if (!btn) return;
        try { btn.disabled = !document.queryCommandEnabled(cmd); } catch (e) { /* navegador sem suporte — deixa habilitado */ }
    });
}
document.addEventListener('selectionchange', () => {
    const editor = document.getElementById('anotacao-corpo');
    if (!editor) return;
    const sel = window.getSelection();
    if (!sel || !sel.anchorNode || !editor.contains(sel.anchorNode)) return;
    atualizarEstadoToolbarAnotacao();
});

// --- Popovers da barra de ferramentas (cor, tamanho, grade de tabela) ---
// Guarda a seleção de texto feita no editor antes de abrir um popover — clicar
// num botão da toolbar tiraria o foco do editor e perderia a seleção, então
// salvamos o Range aqui (o onmousedown com preventDefault nos botões evita que
// o navegador desfaça a seleção antes mesmo do clique acontecer).
let rteSelecaoSalva = null;
function salvarSelecaoRte() {
    const sel = window.getSelection();
    if (sel && sel.rangeCount > 0 && document.getElementById('anotacao-corpo').contains(sel.anchorNode)) {
        rteSelecaoSalva = sel.getRangeAt(0).cloneRange();
    }
}
function restaurarSelecaoRte() {
    const editor = document.getElementById('anotacao-corpo');
    editor.focus();
    if (rteSelecaoSalva) {
        const sel = window.getSelection();
        sel.removeAllRanges();
        sel.addRange(rteSelecaoSalva);
    }
}
function fecharPopoversRte() {
    document.querySelectorAll('.rte-popover').forEach(p => { p.style.display = 'none'; p.style.left = '0'; p.style.right = 'auto'; });
}
function toggleRtePopover(id) {
    salvarSelecaoRte();
    const pop = document.getElementById(id);
    const estavaAberto = pop.style.display === 'block';
    fecharPopoversRte();
    // A barra rola para o lado (overflow) e o Safari corta qualquer menu que esteja dentro dela, mesmo fixo: o menu é levado para fora, direto no body.
    if (!pop._wrap) pop._wrap = pop.closest('.rte-popover-wrap');
    if (pop.parentElement !== document.body) { document.body.appendChild(pop); pop.classList.add('rte-solto'); }
    pop.style.display = estavaAberto ? 'none' : 'block';
    if (id === 'rte-table-popover') montarGradeTabela();
    if (id === 'rte-size-popover') atualizarSizePopoverAtivo();
    if (id === 'rte-spacing-popover') atualizarPopoverEspacamentoAtivo();
    if (!estavaAberto) posicionarPopoverDentroDaTela(pop);
}
// Os botões de tamanho/espaçamento/tabela ficam perto da borda direita da
// toolbar (ela tem 2 fileiras de ícones, muitos botões). O popover sempre
// abria alinhado à esquerda do próprio botão (left:0) sem checar se cabia na
// tela — perto da borda direita ele estourava pra fora e ficava flutuando
// sobre o conteúdo, cortado. Agora mede a posição real antes de mostrar e
// alinha pela direita quando não há espaço suficiente à esquerda.
function posicionarPopoverDentroDaTela(pop) {
    // A barra de formatação agora é uma cápsula fixa embaixo (como na Apple), que rola para o lado: o popover abre "fixo" logo acima
    // dela, centralizado no botão e sem estourar a tela (um popover dentro da barra rolável seria cortado).
    const wrap = pop._wrap || pop.closest('.rte-popover-wrap'), dock = document.getElementById('rte-dock'); if (!wrap || !dock) return;
    const br = wrap.getBoundingClientRect(), dr = dock.getBoundingClientRect();
    pop.style.position = 'fixed'; pop.style.top = 'auto'; pop.style.right = 'auto';
    if (window.matchMedia('(min-width:900px)').matches) { pop.style.bottom = 'auto'; pop.style.top = Math.round(dr.bottom + 10) + 'px'; }   // computador: a barra fica no topo, o menu abre embaixo dela
    else { pop.style.top = 'auto'; pop.style.bottom = Math.round(window.innerHeight - dr.top + 10) + 'px'; }
    const w = pop.getBoundingClientRect().width;
    pop.style.left = Math.round(Math.max(8, Math.min(br.left + br.width / 2 - w / 2, window.innerWidth - w - 8))) + 'px';
}
document.addEventListener('click', (event) => {
    if (!event.target.closest('.rte-popover-wrap') && !event.target.closest('.rte-popover')) fecharPopoversRte();
});

// --- Cor do texto ---
function aplicarCorTextoAnotacao(cor) {
    restaurarSelecaoRte();
    document.execCommand('foreColor', false, cor || 'inherit');
    fecharPopoversRte();
    agendarAutoSaveAnotacao();
}

// --- Tamanho do texto (em px) ---
// execCommand('fontSize') só aceita valores de 1 a 7 (sem controle em px), então
// envolvemos a seleção manualmente num <span style="font-size:Npx">.
function aplicarTamanhoTextoAnotacao(px) {
    restaurarSelecaoRte();
    const sel = window.getSelection();
    if (!sel || sel.rangeCount === 0 || sel.isCollapsed) { fecharPopoversRte(); return; }
    const range = sel.getRangeAt(0);
    const span = document.createElement('span');
    span.style.fontSize = px + 'px';
    try {
        range.surroundContents(span);
    } catch (e) {
        // Seleção atravessa múltiplos elementos (ex: parte de duas linhas) —
        // nesse caso, extrai o conteúdo e envolve manualmente.
        span.appendChild(range.extractContents());
        range.insertNode(span);
    }
    sel.removeAllRanges();
    fecharPopoversRte();
    agendarAutoSaveAnotacao();
}

// Detecta o tamanho de fonte no ponto do cursor/seleção, subindo pela árvore
// do DOM até achar um <span style="font-size:...">. Usado só pra marcar a
// opção certa com um check quando o popover abre — não é fixo, reflete o
// estado real.
function obterTamanhoFonteAtual() {
    const editor = document.getElementById('anotacao-corpo');
    const sel = window.getSelection();
    if (!editor || !sel || !sel.rangeCount) return 16;
    let node = sel.anchorNode;
    if (node && node.nodeType !== 1) node = node.parentNode;
    while (node && node !== editor && editor.contains(node)) {
        if (node.style && node.style.fontSize) {
            const px = parseInt(node.style.fontSize, 10);
            if (!isNaN(px)) return px;
        }
        node = node.parentNode;
    }
    return 16;
}
function atualizarSizePopoverAtivo() {
    const atual = obterTamanhoFonteAtual();
    document.querySelectorAll('.rte-size-option[data-size]').forEach(btn => {
        btn.classList.toggle('active', parseInt(btn.dataset.size, 10) === atual);
    });
}

// --- Espaçamento entre linhas / parágrafos ---
// Aplicado ao documento inteiro (não por parágrafo — mantém a implementação
// simples, como pedido), e persistido como campo próprio da anotação, então
// volta a aparecer do jeito que foi deixado da próxima vez que a nota abrir.
const ESPACAMENTOS_LINHA_ANOTACAO = { simples: '1.35', '115': '1.55', '15': '1.9', duplo: '2.3' };
let editorEspacamentoLinhaAtual = '';
let editorParagrafoCompactoAtual = false;
function aplicarEstadoEspacamentoEditor(valorLineHeight, compacto) {
    const editor = document.getElementById('anotacao-corpo');
    if (!editor) return;
    editor.style.lineHeight = valorLineHeight || '';
    editor.classList.toggle('rte-compacto', !!compacto);
    editorEspacamentoLinhaAtual = valorLineHeight || '';
    editorParagrafoCompactoAtual = !!compacto;
}
function aplicarEspacamentoLinhaAnotacao(chave) {
    const valor = ESPACAMENTOS_LINHA_ANOTACAO[chave] || '';
    const editor = document.getElementById('anotacao-corpo');
    if (editor) editor.style.lineHeight = valor;
    editorEspacamentoLinhaAtual = valor;
    atualizarPopoverEspacamentoAtivo();
    fecharPopoversRte();
    agendarAutoSaveAnotacao();
}
function alternarParagrafoCompactoAnotacao() {
    const editor = document.getElementById('anotacao-corpo');
    if (!editor) return;
    editorParagrafoCompactoAtual = !editorParagrafoCompactoAtual;
    editor.classList.toggle('rte-compacto', editorParagrafoCompactoAtual);
    atualizarPopoverEspacamentoAtivo();
    agendarAutoSaveAnotacao();
}
function atualizarPopoverEspacamentoAtivo() {
    document.querySelectorAll('.rte-size-option[data-spacing]').forEach(btn => {
        btn.classList.toggle('active', (ESPACAMENTOS_LINHA_ANOTACAO[btn.dataset.spacing] || '') === editorEspacamentoLinhaAtual);
    });
    const btnCompacto = document.getElementById('rte-btn-compacto');
    if (btnCompacto) btnCompacto.classList.toggle('active', editorParagrafoCompactoAtual);
}

// --- Tabela: grade visual estilo Word/Google Docs, em vez de prompt() ---
function montarGradeTabela() {
    const grid = document.getElementById('rte-table-grid');
    const label = document.getElementById('rte-table-grid-label');
    if (grid.childElementCount > 0) return; // já montada, só reaproveita
    for (let l = 1; l <= 6; l++) {
        for (let c = 1; c <= 6; c++) {
            const cell = document.createElement('div');
            cell.dataset.linhas = l;
            cell.dataset.colunas = c;
            cell.onmouseenter = () => destacarGradeTabela(l, c);
            cell.onclick = () => { inserirTabelaAnotacao(l, c); };
            grid.appendChild(cell);
        }
    }
    grid.onmouseleave = () => { label.textContent = 'Selecione o tamanho'; destacarGradeTabela(0, 0); };
}
function destacarGradeTabela(linhas, colunas) {
    document.getElementById('rte-table-grid-label').textContent = linhas && colunas ? `${linhas} x ${colunas}` : 'Selecione o tamanho';
    document.querySelectorAll('#rte-table-grid div').forEach(cell => {
        const l = parseInt(cell.dataset.linhas), c = parseInt(cell.dataset.colunas);
        cell.classList.toggle('rte-cell-hover', l <= linhas && c <= colunas);
    });
}

// Insere uma tabela editável no ponto do cursor — permite montar ou colar um
// pedaço de planilha (ao copiar células do Excel/Google Sheets e colar aqui
// dentro, o navegador já preserva a tabela automaticamente também).
function inserirTabelaAnotacao(linhas, colunas) {
    if (!linhas || !colunas) return;
    restaurarSelecaoRte();

    let html = '<table class="anotacao-tabela"><tbody>';
    for (let i = 0; i < linhas; i++) {
        html += '<tr>';
        for (let j = 0; j < colunas; j++) {
            html += '<td>&nbsp;</td>';
        }
        html += '</tr>';
    }
    html += '</tbody></table><p><br></p>';

    document.execCommand('insertHTML', false, html);
    fecharPopoversRte();
    agendarAutoSaveAnotacao();
}
/* ARQ_V */ (window.ARQ_V = window.ARQ_V || {})['js/09-anotacoes.js'] = '2.22.6';
