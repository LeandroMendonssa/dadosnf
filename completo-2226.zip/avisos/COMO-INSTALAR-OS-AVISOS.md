# Como ligar as notificações no iPhone (Cloudflare grátis, ~15 minutos)

Você já tem conta na Cloudflare (do Assistente). Nada aqui tem custo.

## 1) Chave de acesso ao Firebase (conta de serviço)
1. console.firebase.google.com → seu projeto **dadosnf-38b2f** → engrenagem ⚙ → **Configurações do projeto** → aba **Contas de serviço**.
2. **Gerar nova chave privada** → confirme. Baixa um arquivo `.json`. **Guarde: é uma senha. Não envie a ninguém nem para mim.**
3. Abra o arquivo no bloco de notas e copie **o conteúdo inteiro**.

## 2) Criar o Worker
1. Cloudflare → **Workers & Pages → Create → Create Worker**. Nome exatamente: `avisos-auditoria` → **Deploy**.
2. **Edit code** → apague tudo → cole o conteúdo de `worker-avisos.js` → **Deploy**.
3. Se o endereço do seu Worker não for `https://avisos-auditoria.aseleandro.workers.dev`, avise-me (o endereço está dentro do app e do Worker).

## 3) Segredos
No Worker: **Settings → Variables and Secrets → Add** (tipo **Secret**):
- `FIREBASE_SA` = o conteúdo inteiro do arquivo `.json` do passo 1.
- `VAPID_PRIVADA` = `IFSrY8702F2QeBwizesxjXkLj11pv2aGj7h7Pv5GhPI`

Depois **Deploy**.

## 4) Agendamento
No Worker: **Settings → Trigger Events → Add → Cron Triggers** → `*/15 * * * *` (a cada 15 minutos) → Add.

## 5) Permissão do Firebase
No console do Google Cloud (console.cloud.google.com, mesmo projeto), a conta de serviço criada no passo 1 já tem acesso ao Firestore (papel "Firebase Admin SDK"). Se o teste der erro "Firestore 403", avise-me.

## 6) iPhone
1. Atualize o app (publique os arquivos novos, incluindo `sw.js` na mesma pasta do `index.html`).
2. Safari → abra o app → Compartilhar → **Adicionar à Tela de Início** (se ainda não estiver) → abra **pelo ícone**.
3. Mais → Agenda de trabalho → **Ativar notificações** → Permitir → **Enviar teste**.

## Limites e cuidados
- O iPhone precisa estar com iOS 16.4 ou mais novo.
- Notificação pode atrasar até ~15 minutos (o agendamento é de 15 em 15).
- O aviso só dispara para lembretes que ainda não foram marcados como entregues/concluídos.
- Cada pessoa ativa no próprio aparelho e escolhe os avisos que quer.
