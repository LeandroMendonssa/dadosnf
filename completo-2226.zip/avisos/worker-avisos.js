// @ts-nocheck
// Avisos no iPhone — Cloudflare Worker (plano gratuito). Roda sozinho a cada 15 minutos e manda notificações push.
// Veja COMO-INSTALAR-OS-AVISOS.md. Segredos (Settings → Variables and Secrets, tipo Secret):
//   FIREBASE_SA      conteúdo inteiro do arquivo JSON da conta de serviço do Firebase
//   VAPID_PRIVADA    chave privada de envio (o texto que veio no passo a passo)
// O que ele avisa: lembretes da Agenda de trabalho (véspera, no dia, último dia da janela) e NFs da relação vencendo hoje/amanhã (1 vez por dia).
const PROJETO = 'dadosnf-38b2f';
const API_KEY = 'AIzaSyBbJnhZuL5f9v7KYjJRa1uGY9g17JXkYlo';              // apiKey do app (pública)
const VAPID_PUBLICA = 'BMt0bb-qJP1tMXYEsGJ3jVcBMOfy3fQlLlXMxbkfwUvrdL8rolHF9CfHj9pv7_FTHnDhTmyqQEkFl4x9ymf1IF4';
const SUBJECT = 'https://avisos-auditoria.aseleandro.workers.dev';
const FUSO_HORAS = -3;                                                   // Brasília (sem horário de verão)
const HORA_PADRAO = '08:00';
const JANELA_MIN = 12 * 60;                                              // se o aviso atrasar (ex.: celular sem rede), ainda vale por 12 h
const BASE = `https://firestore.googleapis.com/v1/projects/${PROJETO}/databases/(default)/documents`;
const CORS = { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Headers': 'Authorization, Content-Type', 'Access-Control-Allow-Methods': 'POST, OPTIONS' };
const resp = (o, s = 200) => new Response(JSON.stringify(o), { status: s, headers: { ...CORS, 'Content-Type': 'application/json' } });

// ---------- util ----------
const b64u = b => btoa(String.fromCharCode(...new Uint8Array(b))).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
const deB64u = s => { s = s.replace(/-/g, '+').replace(/_/g, '/'); s += '='.repeat((4 - s.length % 4) % 4); return Uint8Array.from(atob(s), c => c.charCodeAt(0)); };
const enc = new TextEncoder();
const cat = (...a) => { const o = new Uint8Array(a.reduce((n, x) => n + x.length, 0)); let p = 0; a.forEach(x => { o.set(x, p); p += x.length; }); return o; };
const localAgora = () => new Date(Date.now() + FUSO_HORAS * 3600e3);          // "relógio de Brasília" lido com os métodos UTC
const isoDia = d => d.toISOString().slice(0, 10);
const minutos = (dia, hhmm) => Date.parse(`${dia}T${hhmm || HORA_PADRAO}:00Z`) / 60000;
const addDias = (iso, n) => isoDia(new Date(Date.parse(iso + 'T12:00:00Z') + n * 86400000));
const difDias = (a, b) => Math.round((Date.parse(b + 'T12:00:00Z') - Date.parse(a + 'T12:00:00Z')) / 86400000);
const addMes = (iso, n, dia) => { const d = new Date(Date.parse(iso + 'T12:00:00Z')); const y = d.getUTCFullYear(), m = d.getUTCMonth() + n; const ult = new Date(Date.UTC(y, m + 1, 0)).getUTCDate(); return isoDia(new Date(Date.UTC(y, m, Math.min(dia, ult), 12))); };

// mesma regra de repetição do app (js/40)
function ocorrencias(it, ini, fim) {
  const dur = it.ate && it.ate > it.de ? difDias(it.de, it.ate) : 0, out = [];
  const push = s => { const e = addDias(s, dur); if (e >= ini && s <= fim) out.push({ de: s, ate: e, campo: 'd' + s.replace(/-/g, '') }); };
  const rep = it.rep || 'n';
  if (!it.de) return out;
  if (rep === 'n') push(it.de);
  else if (rep === 's1' || rep === 's4') { const passo = rep === 's1' ? 7 : 28, k = Math.max(0, Math.floor((difDias(it.de, ini) - dur) / passo)); for (let s = addDias(it.de, k * passo); s <= fim; s = addDias(s, passo)) push(s); }
  else if (rep === 'm') { const dia = Number(it.de.slice(8)); for (let n = 0; n < 600; n++) { const s = addMes(it.de, n, dia); if (s > fim) break; push(s); } }
  else if (rep === 'a') { const dia = Number(it.de.slice(8)); for (let n = 0; n < 60; n++) { const s = addMes(it.de, 12 * n, dia); if (s > fim) break; push(s); } }
  return out;
}

// ---------- Firestore (REST, conta de serviço) ----------
// Lê a chave da conta de serviço mesmo que o painel tenha trocado aspas ou quebras de linha ao salvar o segredo
function lerSA(txt) {
  const t = String(txt || '').replace(/^\uFEFF/, '').trim();
  try { return JSON.parse(t); } catch (_) { }
  try { return JSON.parse(t.replace(/[\u201C\u201D\u201E]/g, '"').replace(/[\u2018\u2019]/g, "'")); } catch (_) { }
  const email = (t.match(/client_email["'\u201C\u201D]?\s*[:=]\s*["'\u201C\u201D]([^"'\u201C\u201D]+)/) || [])[1];
  const chave = (t.match(/-----BEGIN PRIVATE KEY-----[\s\S]*?-----END PRIVATE KEY-----/) || [])[0];
  if (!email || !chave) throw new Error('FIREBASE_SA ilegível: ' + t.length + ' caracteres, começa com ' + JSON.stringify(t.slice(0, 3)));
  return { client_email: email, private_key: chave };
}
let _tok = null;
async function tokenGoogle(env) {
  if (_tok && _tok.exp > Date.now() + 60000) return _tok.v;
  const sa = lerSA(env.FIREBASE_SA), agora = Math.floor(Date.now() / 1000);
  const cab = b64u(enc.encode(JSON.stringify({ alg: 'RS256', typ: 'JWT' })));
  const cor = b64u(enc.encode(JSON.stringify({ iss: sa.client_email, scope: 'https://www.googleapis.com/auth/datastore', aud: 'https://oauth2.googleapis.com/token', iat: agora, exp: agora + 3600 })));
  const pem = sa.private_key.replace(/-----[A-Z ]+-----/g, '').replace(/\\n/g, '').replace(/\s+/g, '');
  const chave = await crypto.subtle.importKey('pkcs8', Uint8Array.from(atob(pem), c => c.charCodeAt(0)), { name: 'RSASSA-PKCS1-v1_5', hash: 'SHA-256' }, false, ['sign']);
  const sig = b64u(await crypto.subtle.sign('RSASSA-PKCS1-v1_5', chave, enc.encode(cab + '.' + cor)));
  const r = await fetch('https://oauth2.googleapis.com/token', { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: 'grant_type=urn:ietf:params:oauth:grant-type:jwt-bearer&assertion=' + cab + '.' + cor + '.' + sig });
  const j = await r.json(); if (!j.access_token) throw new Error('Token Google: ' + JSON.stringify(j).slice(0, 200));
  _tok = { v: j.access_token, exp: Date.now() + (j.expires_in || 3600) * 1000 }; return _tok.v;
}
function dec(v) {
  if (!v) return null;
  if ('stringValue' in v) return v.stringValue; if ('integerValue' in v) return Number(v.integerValue); if ('doubleValue' in v) return v.doubleValue;
  if ('booleanValue' in v) return v.booleanValue; if ('timestampValue' in v) return v.timestampValue; if ('nullValue' in v) return null;
  if ('mapValue' in v) return decCampos(v.mapValue.fields || {}); if ('arrayValue' in v) return (v.arrayValue.values || []).map(dec); return null;
}
const decCampos = f => Object.fromEntries(Object.entries(f || {}).map(([k, v]) => [k, dec(v)]));
async function fs(env, caminho, opc = {}) {
  const r = await fetch(BASE + caminho, { ...opc, headers: { Authorization: 'Bearer ' + await tokenGoogle(env), 'Content-Type': 'application/json' } });
  if (r.status === 404) return null;
  if (!r.ok) throw new Error(`Firestore ${r.status}: ${(await r.text()).slice(0, 200)}`);
  return r.json();
}
const lerDoc = async (env, c, id) => { const d = await fs(env, `/${c}/${id}`); return d ? decCampos(d.fields) : null; };
async function pushDocs(env) {   // documentos config/push_<uid>
  const r = await fetch(`${BASE}:runQuery`, { method: 'POST', headers: { Authorization: 'Bearer ' + await tokenGoogle(env), 'Content-Type': 'application/json' }, body: JSON.stringify({ structuredQuery: { from: [{ collectionId: 'config' }],
    where: { compositeFilter: { op: 'AND', filters: [
      { fieldFilter: { field: { fieldPath: '__name__' }, op: 'GREATER_THAN_OR_EQUAL', value: { referenceValue: `projects/${PROJETO}/databases/(default)/documents/config/push_` } } },
      { fieldFilter: { field: { fieldPath: '__name__' }, op: 'LESS_THAN', value: { referenceValue: `projects/${PROJETO}/databases/(default)/documents/config/push` + '`' } } }] } } } }) });
  if (!r.ok) throw new Error('runQuery ' + r.status + ' ' + (await r.text()).slice(0, 200));
  return (await r.json()).filter(x => x.document).map(x => ({ uid: x.document.name.split('/').pop().replace(/^push_/, ''), ...decCampos(x.document.fields) }));
}
async function gravarCampos(env, c, id, valores, apagar = []) {   // valores: { 'a.b': 'texto' }; apagar: ['a.b']
  const campos = {}, mask = [];
  const aninhar = (caminho, v) => { const p = caminho.split('.'); let alvo = campos; p.forEach((k, i) => { if (i === p.length - 1) alvo[k] = { stringValue: v }; else { alvo[k] = alvo[k] || { mapValue: { fields: {} } }; alvo = alvo[k].mapValue.fields; } }); };
  Object.entries(valores).forEach(([k, v]) => { aninhar(k, v); mask.push(k); }); apagar.forEach(k => mask.push(k));
  await fs(env, `/${c}/${id}?${mask.map(m => 'updateMask.fieldPaths=' + encodeURIComponent(m.split('.').map(x => '`' + x + '`').join('.'))).join('&')}`, { method: 'PATCH', body: JSON.stringify({ fields: campos }) });
}

// ---------- Web Push (RFC 8291 aes128gcm + VAPID) ----------
async function hkdf(salt, ikm, info, bytes) {
  const k = await crypto.subtle.importKey('raw', ikm, 'HKDF', false, ['deriveBits']);
  return new Uint8Array(await crypto.subtle.deriveBits({ name: 'HKDF', hash: 'SHA-256', salt, info }, k, bytes * 8));
}
async function jwtVapid(env, endpoint) {
  const aud = new URL(endpoint).origin, pub = deB64u(VAPID_PUBLICA);
  const cab = b64u(enc.encode(JSON.stringify({ typ: 'JWT', alg: 'ES256' })));
  const cor = b64u(enc.encode(JSON.stringify({ aud, exp: Math.floor(Date.now() / 1000) + 12 * 3600, sub: SUBJECT })));
  const chave = await crypto.subtle.importKey('jwk', { kty: 'EC', crv: 'P-256', d: env.VAPID_PRIVADA.trim(), x: b64u(pub.slice(1, 33)), y: b64u(pub.slice(33, 65)) }, { name: 'ECDSA', namedCurve: 'P-256' }, false, ['sign']);
  const sig = b64u(await crypto.subtle.sign({ name: 'ECDSA', hash: 'SHA-256' }, chave, enc.encode(cab + '.' + cor)));
  return `vapid t=${cab}.${cor}.${sig}, k=${VAPID_PUBLICA}`;
}
async function enviarPush(env, sub, payload) {   // devolve o status HTTP do serviço de push (201 = ok; 404/410 = aparelho não existe mais)
  const uaPub = deB64u(sub.p256dh), auth = deB64u(sub.auth), salt = crypto.getRandomValues(new Uint8Array(16));
  const par = await crypto.subtle.generateKey({ name: 'ECDH', namedCurve: 'P-256' }, true, ['deriveBits']);
  const asPub = new Uint8Array(await crypto.subtle.exportKey('raw', par.publicKey));
  const uaChave = await crypto.subtle.importKey('raw', uaPub, { name: 'ECDH', namedCurve: 'P-256' }, false, []);
  const segredo = new Uint8Array(await crypto.subtle.deriveBits({ name: 'ECDH', public: uaChave }, par.privateKey, 256));
  const prk = await hkdf(auth, segredo, cat(enc.encode('WebPush: info\0'), uaPub, asPub), 32);
  const cek = await hkdf(salt, prk, enc.encode('Content-Encoding: aes128gcm\0'), 16), nonce = await hkdf(salt, prk, enc.encode('Content-Encoding: nonce\0'), 12);
  const aes = await crypto.subtle.importKey('raw', cek, 'AES-GCM', false, ['encrypt']);
  const cifra = new Uint8Array(await crypto.subtle.encrypt({ name: 'AES-GCM', iv: nonce }, aes, cat(enc.encode(JSON.stringify(payload)), new Uint8Array([2]))));
  const corpo = cat(salt, new Uint8Array([0, 0, 16, 0, 65]), asPub, cifra);   // 4096 = tamanho do registro
  const r = await fetch(sub.endpoint, { method: 'POST', headers: { Authorization: await jwtVapid(env, sub.endpoint), 'Content-Encoding': 'aes128gcm', 'Content-Type': 'application/octet-stream', TTL: '43200', Urgency: 'high' }, body: corpo });
  return r.status;
}
async function enviarAoUsuario(env, u, payload) {   // manda para todos os aparelhos da pessoa e apaga os que não existem mais
  let ok = 0;
  for (const [id, s] of Object.entries(u.subs || {})) {
    if (!s || !s.endpoint) continue;
    let st = 0; try { st = await enviarPush(env, s, payload); } catch (e) { console.log('push erro', e.message); }
    if (st >= 200 && st < 300) ok++;
    else if (st === 404 || st === 410) { try { await gravarCampos(env, 'config', 'push_' + u.uid, {}, ['subs.' + id]); } catch (e) { } }
    else console.log('push status', st);
  }
  return ok;
}

// ---------- rotina (a cada 15 min) ----------
async function rotina(env) {
  const usuarios = (await pushDocs(env)).filter(u => u.subs && Object.keys(u.subs).length);
  if (!usuarios.length) return { usuarios: 0 };
  const agora = localAgora(), hoje = isoDia(agora), agoraMin = Date.parse(agora.toISOString().slice(0, 16) + ':00Z') / 60000;
  const enviados = (await lerDoc(env, 'config', 'pushEnviados')) || {}, jaEnviado = (enviados.ks) || {};
  const novos = {}; let enviadosAgora = 0;
  const marcar = k => { novos['ks.' + k] = new Date(Date.now()).toISOString(); };
  const chaveSegura = s => 'k' + s.replace(/[^A-Za-z0-9]/g, '_');

  // 1) agenda
  const agenda = ((await lerDoc(env, 'config', 'agendaTrabalho')) || {}).itens || {};
  const eventos = [];
  Object.values(agenda).forEach(it => {
    if (!it || !it.de) return;
    const catg = it.tipo === 'entrega' ? 'entregas' : it.tipo === 'reuniao' ? 'reunioes' : 'lembretes', nome = (it.titulo || 'Lembrete') + (it.empresa ? ' · ' + it.empresa : '');
    ocorrencias(it, addDias(hoje, -1), addDias(hoje, 2)).forEach(o => {
      if ((it.feitas || {})[o.campo]) return;
      const h = it.hora ? ' às ' + it.hora : '', janela = o.ate > o.de ? ` (até ${o.ate.slice(8)}/${o.ate.slice(5, 7)})` : '';
      if (it.vespera !== false) eventos.push({ catg, ev: 'v', when: minutos(addDias(o.de, -1), it.hora), id: it.id + o.campo, titulo: 'Amanhã', corpo: nome + janela + h });
      if (it.dia !== false) eventos.push({ catg, ev: 'd', when: minutos(o.de, it.hora), id: it.id + o.campo, titulo: it.tipo === 'reuniao' ? 'Reunião hoje' : 'Hoje', corpo: nome + janela + h });
      if (it.dia !== false && it.tipo === 'entrega' && o.ate > o.de) eventos.push({ catg, ev: 'f', when: minutos(o.ate, it.hora), id: it.id + o.campo, titulo: 'Último dia da janela', corpo: nome + ' — marque como entregue no app' });
    });
  });
  for (const e of eventos) {
    if (agoraMin < e.when || agoraMin >= e.when + JANELA_MIN) continue;
    for (const u of usuarios) {
      if ((u.avisos || {})[e.catg] === false) continue;
      const k = chaveSegura(`${u.uid}|${e.id}|${e.ev}`);
      if (jaEnviado[k]) continue;
      if (await enviarAoUsuario(env, u, { titulo: e.titulo, corpo: e.corpo, tag: k, url: './index.html?abrir=agenda' })) { marcar(k); enviadosAgora++; }
    }
  }

  // 2) NFs da relação vencendo hoje/amanhã — uma vez por dia, a partir das 08:00
  if (agora.getUTCHours() >= 8) {
    const alvo = usuarios.filter(u => (u.avisos || {}).nfVencendo !== false && !jaEnviado[chaveSegura(`nf|${u.uid}|${hoje}`)]);
    if (alvo.length) {
      const amanha = addDias(hoje, 1), br = iso => iso.slice(8) + '/' + iso.slice(5, 7) + '/' + iso.slice(0, 4);
      const nfs = []; let pagina = '';
      do {
        const r = await fs(env, `/notas?pageSize=300&mask.fieldPaths=vencimento&mask.fieldPaths=enviada&mask.fieldPaths=fornecedor&mask.fieldPaths=nf${pagina ? '&pageToken=' + pagina : ''}`);
        (r && r.documents || []).forEach(d => nfs.push(decCampos(d.fields))); pagina = r && r.nextPageToken || '';
      } while (pagina);
      const abertas = nfs.filter(n => !n.enviada && n.vencimento);
      const nHoje = abertas.filter(n => n.vencimento === br(hoje)).length, nAman = abertas.filter(n => n.vencimento === br(amanha)).length;
      for (const u of alvo) {
        if (nHoje + nAman) { const partes = []; if (nHoje) partes.push(`${nHoje} vence(m) hoje`); if (nAman) partes.push(`${nAman} vence(m) amanhã`); if (await enviarAoUsuario(env, u, { titulo: 'NFs na relação', corpo: partes.join(' · '), tag: 'nf', url: './index.html?abrir=notas' })) enviadosAgora++; }
        marcar(chaveSegura(`nf|${u.uid}|${hoje}`));
      }
    }
  }

  // 2b) ocorrências em aberto e pedidos parados — uma vez por dia, a partir das 08:00, com os números que o app anotou em config/avisosResumo
  if (agora.getUTCHours() >= 8) {
    const alvo = usuarios.filter(u => ((u.avisos || {}).ocorrencias !== false || (u.avisos || {}).pedidosParados !== false) && !jaEnviado[chaveSegura(`res|${u.uid}|${hoje}`)]);
    if (alvo.length) {
      const res = await lerDoc(env, 'config', 'avisosResumo');
      if (res && res.atualizadoEm && Date.now() - Date.parse(res.atualizadoEm) < 3 * 86400e3) {
        for (const u of alvo) {
          const nO = (u.avisos || {}).ocorrencias !== false ? Number(res.ocorrencias) || 0 : 0, nP = (u.avisos || {}).pedidosParados !== false ? Number(res.pedidosParados) || 0 : 0;
          const partes = []; if (nO) partes.push(`${nO} ocorrência(s) em aberto sem relato`); if (nP) partes.push(`${nP} pedido(s) parado(s) sem entrega`);
          if (partes.length && await enviarAoUsuario(env, u, { titulo: 'Pendências na auditoria', corpo: partes.join(' · '), tag: 'resumo', url: './index.html' })) enviadosAgora++;
          marcar(chaveSegura(`res|${u.uid}|${hoje}`));
        }
      }
    }
  }

  // 3) grava o que foi enviado e limpa registros com mais de 3 dias
  const velhos = Object.entries(jaEnviado).filter(([, t]) => Date.now() - Date.parse(t) > 3 * 86400e3).map(([k]) => 'ks.' + k);
  if (Object.keys(novos).length || velhos.length) await gravarCampos(env, 'config', 'pushEnviados', novos, velhos);
  return { usuarios: usuarios.length, eventos: eventos.length, enviados: enviadosAgora };
}

export default {
  async scheduled(ev, env, ctx) {
    ctx.waitUntil((async () => {
      let r = {}, erro = '';
      try { r = await rotina(env); console.log('rotina', JSON.stringify(r)); } catch (e) { erro = String(e.message || e).slice(0, 200); console.log('ERRO rotina', erro); }
      try { await gravarCampos(env, 'config', 'pushStatus', { ultimaRodada: new Date().toISOString(), usuarios: String(r.usuarios || 0), enviados: String(r.enviados || 0), erro }, []); } catch (e) { console.log('status não gravado', e.message); }
    })());
  },
  async fetch(req, env) {
    if (req.method === 'OPTIONS') return new Response(null, { headers: CORS });
    if (req.method !== 'POST') return resp({ ok: true, servico: 'avisos-auditoria', versao: '2.20.9' });
    // POST /teste — só para quem está logado no app: manda uma notificação de teste aos aparelhos dela
    try {
      const idToken = (req.headers.get('Authorization') || '').replace(/^Bearer\s+/i, '');
      if (!idToken) return resp({ erro: 'sem login' }, 401);
      const r = await fetch('https://identitytoolkit.googleapis.com/v1/accounts:lookup?key=' + API_KEY, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ idToken }) });
      const j = await r.json(), uid = j.users && j.users[0] && j.users[0].localId; if (!uid) return resp({ erro: 'login inválido' }, 401);
      const doc = await lerDoc(env, 'config', 'push_' + uid); if (!doc || !doc.subs) return resp({ erro: 'nenhum aparelho cadastrado' }, 404);
      const n = await enviarAoUsuario(env, { uid, subs: doc.subs }, { titulo: 'Teste de aviso', corpo: 'Se você está vendo isto, as notificações estão funcionando.', tag: 'teste', url: './index.html?abrir=agenda' });
      return resp({ enviados: n });
    } catch (e) { return resp({ erro: e.message }, 500); }
  }
};
