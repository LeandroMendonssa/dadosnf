// Intermediário do Assistente — 100% Cloudflare (Worker + Workers AI, plano gratuito).
// Sem chave de terceiros: a IA roda na própria Cloudflare. Só atende quem está logado no app.
//
// Configuração no painel da Cloudflare (veja COMO-INSTALAR-O-ASSISTENTE.md):
//   Binding   AI                (Settings → Bindings → Add → Workers AI, nome da variável: AI)
//   (as 2 linhas — normalmente não precisa mexer "CONFIGURE AQUI" abaixo substituem as variáveis FIREBASE_API_KEY e ALLOWED_EMAILS; se você criar essas variáveis no painel, elas valem no lugar)
//   Variável  MODEL             (Text)  opcional: padrão @cf/meta/llama-3.3-70b-instruct-fp8-fast (mais leve e rápido: @cf/meta/llama-3.1-8b-instruct-fp8-fast)
//                                        (mais econômico no uso diário grátis: @cf/meta/llama-3.1-8b-instruct-fp8-fast)
// ===== CONFIGURE AQUI (2 linhas — normalmente não precisa mexer) — assim você não precisa criar variáveis no painel =====
const FIREBASE_API_KEY_PADRAO = 'AIzaSyBbJnhZuL5f9v7KYjJRa1uGY9g17JXkYlo';   // apiKey do app (é público, já vem certa)
const EMAILS_PERMITIDOS_PADRAO = '';                        // deixe vazio: qualquer usuário que entra no app pode usar (novos usuários funcionam sozinhos)
// ======================================================================================
const CORS = { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Headers': 'Authorization, Content-Type', 'Access-Control-Allow-Methods': 'POST, OPTIONS' };
const resp = (obj, status = 200) => new Response(JSON.stringify(obj), { status, headers: { ...CORS, 'Content-Type': 'application/json' } });

function extrairTexto(r) {   // modelos diferentes devolvem em formatos diferentes
  if (!r) return '';
  if (typeof r === 'string') return r;
  if (typeof r.response === 'string') return r.response;
  if (r.response && typeof r.response === 'object') return JSON.stringify(r.response);   // alguns modelos devolvem o JSON já convertido
  if (r.result && typeof r.result.response === 'string') return r.result.response;
  const c = r.choices && r.choices[0] && r.choices[0].message && r.choices[0].message.content;
  if (typeof c === 'string') return c;
  if (Array.isArray(r.output)) {
    const m = r.output.find(o => o.type === 'message');
    const t = m && Array.isArray(m.content) && m.content.find(x => x.type === 'output_text');
    if (t && t.text) return t.text;
  }
  return '';
}

export default {
  async fetch(req, env) {
    try { return await tratar(req, env); }
    catch (e) { return resp({ error: 'Erro no Worker: ' + String((e && e.message) || e).slice(0, 200) }, 500); }
  }
};

async function tratar(req, env) {
    if (req.method === 'OPTIONS') return new Response(null, { status: 204, headers: CORS });
    if (req.method !== 'POST') return resp({ error: 'Use POST.' }, 405);
    if (!env.AI) return resp({ error: 'O Worker está sem o binding "AI" (Workers AI). Veja o passo 4 do guia.' }, 500);

    // 1) quem pergunta tem que estar logado no app (token do Firebase conferido no Google)
    const token = (req.headers.get('Authorization') || '').replace(/^Bearer\s+/i, '');
    if (!token) return resp({ error: 'Sem login.' }, 401);
    const chk = await fetch('https://identitytoolkit.googleapis.com/v1/accounts:lookup?key=' + (env.FIREBASE_API_KEY || FIREBASE_API_KEY_PADRAO), {
      method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ idToken: token })
    });
    if (!chk.ok) return resp({ error: 'Login inválido ou expirado.' }, 401);
    const user = ((await chk.json()).users || [])[0];
    if (!user) return resp({ error: 'Login inválido.' }, 401);
    const permitidos = String(env.ALLOWED_EMAILS || EMAILS_PERMITIDOS_PADRAO).split(',').map(s => s.trim().toLowerCase()).filter(e => e && e.includes('@') && e !== 'cole-seu-email-aqui');
    if (permitidos.length && !permitidos.includes(String(user.email || '').toLowerCase())) return resp({ error: 'A conta ' + (user.email || '(sem e-mail)') + ' não está na lista de e-mails permitidos do Assistente.' }, 403);

    // 2) o pedido (limites)
    const raw = await req.text();
    if (raw.length > 300000) return resp({ error: 'Pergunta grande demais.' }, 413);
    let body; try { body = JSON.parse(raw); } catch (e) { return resp({ error: 'JSON inválido.' }, 400); }
    if (!Array.isArray(body.messages) || !body.messages.length || body.messages.length > 20) return resp({ error: 'Mensagens inválidas.' }, 400);
    const msgs = body.messages.filter(m => m && (m.role === 'user' || m.role === 'assistant') && typeof m.content === 'string').map(m => ({ role: m.role, content: m.content.slice(0, 20000) }));
    if (!msgs.length) return resp({ error: 'Mensagens inválidas.' }, 400);

    // 3) a IA da Cloudflare (o Worker decide modelo e tamanho da resposta)
    try {
      const r = await env.AI.run(env.MODEL || '@cf/meta/llama-3.3-70b-instruct-fp8-fast', {
        messages: [{ role: 'system', content: String(body.system || '').slice(0, 12000) }, ...msgs], max_tokens: 900, temperature: 0.2
      });
      const texto = extrairTexto(r);
      if (!texto.trim()) return resp({ error: 'A IA devolveu vazio. Formato recebido: ' + JSON.stringify(r).slice(0, 250) }, 502);
      return resp({ text: texto });
    } catch (e) {
      const m = String((e && e.message) || e);
      return resp({ error: /limit|quota|neuron|capacity/i.test(m) ? 'O limite gratuito de hoje da IA acabou. Volta amanhã (o modo básico continua funcionando).' : 'Erro na IA: ' + m.slice(0, 200) }, 502);
    }
}
