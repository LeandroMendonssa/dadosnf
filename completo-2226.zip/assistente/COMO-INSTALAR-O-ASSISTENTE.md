# Como ligar a IA do Assistente (tudo na Cloudflare, grátis, ~10 minutos, sem terminal)

O Assistente já funciona sem isto, no "modo básico". Este passo a passo liga a IA para perguntas em linguagem livre.
Tudo roda na Cloudflare: **não precisa de chave de terceiros nem cartão de crédito** (confirme na tela se algum passo pedir pagamento: o plano gratuito basta).

## 1) Conta
Entre em **dash.cloudflare.com** e crie uma conta gratuita (e-mail e senha; confirme o e-mail).

## 2) Criar o Worker
1. No menu da esquerda: **Workers & Pages** (ou "Compute (Workers)") → **Create** → **Create Worker**.
2. Nome: `assistente-auditoria` → **Deploy** (ele cria um exemplo "Hello World").
3. Toque em **Edit code**. Apague tudo o que estiver lá e cole **todo** o conteúdo do arquivo `worker-assistente.js`.
4. Toque em **Deploy** (canto superior direito).

## 3) E-mail e chave
Já estão no código que você colou (seu e-mail e a chave do app). Não precisa fazer nada neste passo: vá direto para o passo 4.

## 4) Ligar a IA ao Worker (binding)
No Worker: **Settings → Bindings → Add → Workers AI**. Em **Variable name** escreva exatamente `AI` → **Save/Deploy**.

## 5) App
O endereço do Worker já vem fixo dentro do app (`assistente-auditoria.aseleandro.workers.dev`): não há nada para digitar. Em **Mais → Assistente**, escolha "IA" ou "Modo básico" no seletor embaixo do campo de digitar e pergunte, por exemplo: "O que está pendente hoje e por quê?".
Se você criar o Worker com outro nome ou conta, o endereço precisa ser trocado no app (peça ao responsável pelo código).

## Limite grátis
A Cloudflare dá 10.000 "neurons" de IA por dia no plano gratuito (zera à meia-noite UTC). Passando disso, a IA responde que o limite acabou e **o modo básico continua funcionando**. Nunca há cobrança no plano gratuito.

## Cuidados
- O Assistente só **lê** os dados do app; ele não grava nada.
- Só vão para a IA os resultados das consultas que a pergunta pede (no máximo 25 linhas por consulta), nunca o banco inteiro.
- IA pode errar: confira os números importantes (a resposta mostra de onde veio cada dado).
